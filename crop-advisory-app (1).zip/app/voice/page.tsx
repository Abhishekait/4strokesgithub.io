"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Mic, MicOff, Volume2, VolumeX, ArrowLeft, MessageCircle, Globe, RotateCcw, Zap, User, Bot } from "lucide-react"
import Link from "next/link"

interface VoiceMessage {
  id: string
  type: "user" | "assistant"
  text: string
  timestamp: Date
  language: string
  audioUrl?: string
}

interface VoiceSettings {
  language: string
  voiceSpeed: number
  autoPlay: boolean
}

export default function VoicePage() {
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [messages, setMessages] = useState<VoiceMessage[]>([])
  const [currentTranscript, setCurrentTranscript] = useState("")
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>({
    language: "en-US",
    voiceSpeed: 1,
    autoPlay: true,
  })
  const [isSupported, setIsSupported] = useState(true)
  const recognitionRef = useRef<any>(null)
  const synthRef = useRef<SpeechSynthesis | null>(null)

  useEffect(() => {
    // Check for browser support
    if (typeof window !== "undefined") {
      const hasWebSpeech = "webkitSpeechRecognition" in window || "SpeechRecognition" in window
      const hasSpeechSynthesis = "speechSynthesis" in window
      setIsSupported(hasWebSpeech && hasSpeechSynthesis)

      if (hasWebSpeech) {
        const SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition
        recognitionRef.current = new SpeechRecognition()
        recognitionRef.current.continuous = true
        recognitionRef.current.interimResults = true
        recognitionRef.current.lang = voiceSettings.language

        recognitionRef.current.onresult = (event: any) => {
          let transcript = ""
          for (let i = event.resultIndex; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript
          }
          setCurrentTranscript(transcript)
        }

        recognitionRef.current.onend = () => {
          setIsListening(false)
          if (currentTranscript.trim()) {
            handleUserMessage(currentTranscript)
            setCurrentTranscript("")
          }
        }
      }

      if (hasSpeechSynthesis) {
        synthRef.current = window.speechSynthesis
      }
    }

    // Add welcome message
    const welcomeMessage: VoiceMessage = {
      id: "welcome",
      type: "assistant",
      text: "Welcome to CropAdvisor Voice Assistant! I can help you with crop recommendations, weather updates, pest identification, and market prices. How can I assist you today?",
      timestamp: new Date(),
      language: voiceSettings.language,
    }
    setMessages([welcomeMessage])

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
      if (synthRef.current) {
        synthRef.current.cancel()
      }
    }
  }, [])

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      setIsListening(true)
      setCurrentTranscript("")
      recognitionRef.current.start()
    }
  }

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop()
      setIsListening(false)
    }
  }

  const handleUserMessage = (text: string) => {
    const userMessage: VoiceMessage = {
      id: Date.now().toString(),
      type: "user",
      text: text,
      timestamp: new Date(),
      language: voiceSettings.language,
    }

    setMessages((prev) => [...prev, userMessage])

    // Simulate AI response
    setTimeout(() => {
      const response = generateAIResponse(text)
      const assistantMessage: VoiceMessage = {
        id: (Date.now() + 1).toString(),
        type: "assistant",
        text: response,
        timestamp: new Date(),
        language: voiceSettings.language,
      }

      setMessages((prev) => [...prev, assistantMessage])

      if (voiceSettings.autoPlay) {
        speakText(response)
      }
    }, 1000)
  }

  const generateAIResponse = (userText: string): string => {
    const lowerText = userText.toLowerCase()

    if (lowerText.includes("weather") || lowerText.includes("rain") || lowerText.includes("temperature")) {
      return "Today's weather shows partly cloudy conditions with 28°C temperature and 65% humidity. There's a chance of rain in 2 days, so consider postponing irrigation. Would you like more detailed weather information?"
    }

    if (lowerText.includes("pest") || lowerText.includes("disease") || lowerText.includes("insect")) {
      return "For pest detection, you can upload a photo of affected plants. Common pests this season include aphids and leaf spot. I recommend using neem oil as an organic treatment. Would you like specific pest identification help?"
    }

    if (lowerText.includes("price") || lowerText.includes("market") || lowerText.includes("sell")) {
      return "Current market prices show rice at ₹2,850 per quintal with a 3.6% increase. Tomatoes are performing well at ₹3,500 per quintal, up 9.4%. This might be a good time to sell tomatoes. Would you like prices for specific crops?"
    }

    if (lowerText.includes("crop") || lowerText.includes("plant") || lowerText.includes("grow")) {
      return "Based on current conditions, rice and tomatoes are showing good market potential. For your soil type and location, I recommend rice for the upcoming season. The planting window is June to July. Would you like detailed crop recommendations?"
    }

    if (lowerText.includes("fertilizer") || lowerText.includes("soil") || lowerText.includes("nutrients")) {
      return "For healthy soil, I recommend organic compost and balanced NPK fertilizers. Your soil health appears good based on recent data. Apply organic matter before planting and use nitrogen-rich fertilizers during growth phase. Need specific fertilizer recommendations?"
    }

    return "I understand you're asking about farming. I can help with crop recommendations, weather updates, pest identification, market prices, and soil health. Could you please be more specific about what you'd like to know?"
  }

  const speakText = (text: string) => {
    if (synthRef.current && !isSpeaking) {
      setIsSpeaking(true)
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = voiceSettings.language
      utterance.rate = voiceSettings.voiceSpeed

      utterance.onend = () => {
        setIsSpeaking(false)
      }

      synthRef.current.speak(utterance)
    }
  }

  const stopSpeaking = () => {
    if (synthRef.current) {
      synthRef.current.cancel()
      setIsSpeaking(false)
    }
  }

  const clearConversation = () => {
    setMessages([])
    setCurrentTranscript("")
    if (synthRef.current) {
      synthRef.current.cancel()
    }
    setIsSpeaking(false)
  }

  const getLanguageName = (code: string) => {
    const languages: { [key: string]: string } = {
      "en-US": "English",
      "hi-IN": "Hindi",
      "bn-IN": "Bengali",
      "te-IN": "Telugu",
      "ta-IN": "Tamil",
      "mr-IN": "Marathi",
      "gu-IN": "Gujarati",
      "kn-IN": "Kannada",
      "ml-IN": "Malayalam",
      "pa-IN": "Punjabi",
    }
    return languages[code] || code
  }

  if (!isSupported) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950">
        <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-indigo-200 dark:border-indigo-800">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Back
                </Button>
              </Link>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center">
                  <Mic className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-indigo-800 dark:text-indigo-200">Voice Assistant</h1>
                  <p className="text-sm text-indigo-600 dark:text-indigo-400">Hands-free Support</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className="container mx-auto px-4 py-8">
          <Alert className="border-red-500 bg-red-50 dark:bg-red-950">
            <MicOff className="h-4 w-4" />
            <AlertDescription>
              Voice features are not supported in your browser. Please use a modern browser like Chrome, Firefox, or
              Safari for the best experience.
            </AlertDescription>
          </Alert>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-indigo-200 dark:border-indigo-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Back
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center">
                <Mic className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-indigo-800 dark:text-indigo-200">Voice Assistant</h1>
                <p className="text-sm text-indigo-600 dark:text-indigo-400">Hands-free Support</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Voice Controls */}
          <div className="lg:col-span-1 space-y-6">
            {/* Language Settings */}
            <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="w-5 h-5 text-indigo-600" />
                  Language
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Select
                  value={voiceSettings.language}
                  onValueChange={(value) => setVoiceSettings((prev) => ({ ...prev, language: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en-US">English</SelectItem>
                    <SelectItem value="hi-IN">Hindi</SelectItem>
                    <SelectItem value="bn-IN">Bengali</SelectItem>
                    <SelectItem value="te-IN">Telugu</SelectItem>
                    <SelectItem value="ta-IN">Tamil</SelectItem>
                    <SelectItem value="mr-IN">Marathi</SelectItem>
                    <SelectItem value="gu-IN">Gujarati</SelectItem>
                    <SelectItem value="kn-IN">Kannada</SelectItem>
                    <SelectItem value="ml-IN">Malayalam</SelectItem>
                    <SelectItem value="pa-IN">Punjabi</SelectItem>
                  </SelectContent>
                </Select>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Speech Speed</label>
                  <Select
                    value={voiceSettings.voiceSpeed.toString()}
                    onValueChange={(value) =>
                      setVoiceSettings((prev) => ({ ...prev, voiceSpeed: Number.parseFloat(value) }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0.5">Slow</SelectItem>
                      <SelectItem value="1">Normal</SelectItem>
                      <SelectItem value="1.5">Fast</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Voice Controls */}
            <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="w-5 h-5 text-indigo-600" />
                  Controls
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  onClick={isListening ? stopListening : startListening}
                  className={`w-full ${
                    isListening ? "bg-red-600 hover:bg-red-700" : "bg-indigo-600 hover:bg-indigo-700"
                  }`}
                  size="lg"
                >
                  {isListening ? (
                    <>
                      <MicOff className="w-5 h-5 mr-2" />
                      Stop Listening
                    </>
                  ) : (
                    <>
                      <Mic className="w-5 h-5 mr-2" />
                      Start Listening
                    </>
                  )}
                </Button>

                <Button
                  onClick={isSpeaking ? stopSpeaking : () => {}}
                  disabled={!isSpeaking}
                  variant="outline"
                  className="w-full"
                >
                  {isSpeaking ? (
                    <>
                      <VolumeX className="w-4 h-4 mr-2" />
                      Stop Speaking
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-4 h-4 mr-2" />
                      Not Speaking
                    </>
                  )}
                </Button>

                <Button onClick={clearConversation} variant="outline" className="w-full bg-transparent">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Clear Chat
                </Button>
              </CardContent>
            </Card>

            {/* Status */}
            <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Status:</span>
                    <Badge variant={isListening ? "default" : "secondary"}>{isListening ? "Listening" : "Ready"}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Language:</span>
                    <span className="text-sm font-medium">{getLanguageName(voiceSettings.language)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Messages:</span>
                    <span className="text-sm font-medium">{messages.length}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Chat Interface */}
          <div className="lg:col-span-3">
            <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm h-[600px] flex flex-col">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-indigo-600" />
                  Voice Conversation
                </CardTitle>
                <CardDescription>Speak naturally to get farming advice in your preferred language</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col">
                {/* Messages */}
                <div className="flex-1 overflow-y-auto space-y-4 mb-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex gap-3 ${message.type === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`flex gap-3 max-w-[80%] ${
                          message.type === "user" ? "flex-row-reverse" : "flex-row"
                        }`}
                      >
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                            message.type === "user"
                              ? "bg-indigo-600 text-white"
                              : "bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300"
                          }`}
                        >
                          {message.type === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                        </div>
                        <div
                          className={`p-3 rounded-lg ${
                            message.type === "user"
                              ? "bg-indigo-600 text-white"
                              : "bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                          }`}
                        >
                          <p className="text-sm">{message.text}</p>
                          <div className="flex items-center gap-2 mt-2">
                            <span className="text-xs opacity-70">{message.timestamp.toLocaleTimeString()}</span>
                            {message.type === "assistant" && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-6 w-6 p-0 opacity-70 hover:opacity-100"
                                onClick={() => speakText(message.text)}
                                disabled={isSpeaking}
                              >
                                <Volume2 className="w-3 h-3" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Current Transcript */}
                {currentTranscript && (
                  <div className="p-3 bg-indigo-50 dark:bg-indigo-950 rounded-lg border border-indigo-200 dark:border-indigo-800">
                    <p className="text-sm text-indigo-700 dark:text-indigo-300">
                      <span className="font-medium">Listening:</span> {currentTranscript}
                    </p>
                  </div>
                )}

                {/* Listening Indicator */}
                {isListening && (
                  <div className="flex items-center justify-center p-4">
                    <div className="flex items-center gap-2 text-indigo-600">
                      <div className="w-2 h-2 bg-indigo-600 rounded-full animate-pulse"></div>
                      <div className="w-2 h-2 bg-indigo-600 rounded-full animate-pulse delay-75"></div>
                      <div className="w-2 h-2 bg-indigo-600 rounded-full animate-pulse delay-150"></div>
                      <span className="ml-2 text-sm font-medium">Listening...</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
