"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import {
  Bug,
  Camera,
  Upload,
  ArrowLeft,
  Loader2,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Zap,
  Eye,
  Leaf,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"

interface DetectionResult {
  pest: string
  confidence: number
  severity: "Low" | "Medium" | "High"
  description: string
  symptoms: string[]
  treatment: {
    organic: string[]
    chemical: string[]
    preventive: string[]
  }
  affectedCrops: string[]
  timeToAct: string
}

export default function PestDetectionPage() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [detectionResult, setDetectionResult] = useState<DetectionResult | null>(null)
  const [analysisProgress, setAnalysisProgress] = useState(0)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string)
        setDetectionResult(null)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleAnalyze = async () => {
    if (!selectedImage) return

    setIsAnalyzing(true)
    setAnalysisProgress(0)

    // Simulate AI analysis with progress
    const progressInterval = setInterval(() => {
      setAnalysisProgress((prev) => {
        if (prev >= 90) {
          clearInterval(progressInterval)
          return 90
        }
        return prev + 10
      })
    }, 200)

    // Simulate API call
    setTimeout(() => {
      setAnalysisProgress(100)
      const mockResult: DetectionResult = {
        pest: "Aphids (Green Peach Aphid)",
        confidence: 87,
        severity: "Medium",
        description:
          "Small, soft-bodied insects that feed on plant sap. They can transmit viruses and cause yellowing of leaves.",
        symptoms: [
          "Yellowing or curling of leaves",
          "Sticky honeydew on plant surfaces",
          "Stunted plant growth",
          "Presence of small green insects on undersides of leaves",
        ],
        treatment: {
          organic: [
            "Spray with neem oil solution",
            "Introduce ladybugs as natural predators",
            "Use insecticidal soap spray",
            "Apply diatomaceous earth around plants",
          ],
          chemical: [
            "Apply imidacloprid-based insecticide",
            "Use pyrethroid spray (follow label instructions)",
            "Systemic insecticides for severe infestations",
          ],
          preventive: [
            "Regular monitoring of plants",
            "Remove weeds that harbor aphids",
            "Use reflective mulch to deter aphids",
            "Maintain proper plant spacing for air circulation",
          ],
        },
        affectedCrops: ["Tomatoes", "Peppers", "Cucumbers", "Lettuce", "Beans"],
        timeToAct: "Within 3-5 days for best results",
      }
      setDetectionResult(mockResult)
      setIsAnalyzing(false)
      clearInterval(progressInterval)
    }, 3000)
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "High":
        return "bg-red-100 text-red-800 border-red-300"
      case "Medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-300"
      case "Low":
        return "bg-green-100 text-green-800 border-green-300"
      default:
        return "bg-gray-100 text-gray-800 border-gray-300"
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "High":
        return <XCircle className="w-4 h-4 text-red-600" />
      case "Medium":
        return <AlertTriangle className="w-4 h-4 text-yellow-600" />
      case "Low":
        return <CheckCircle className="w-4 h-4 text-green-600" />
      default:
        return <Eye className="w-4 h-4 text-gray-600" />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-950 dark:to-red-950">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-orange-200 dark:border-orange-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Back
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-orange-600 rounded-lg flex items-center justify-center">
                <Bug className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-orange-800 dark:text-orange-200">Pest Detection</h1>
                <p className="text-sm text-orange-600 dark:text-orange-400">AI-Powered Image Analysis</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Image Upload Section */}
          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-orange-600" />
                Upload Crop Image
              </CardTitle>
              <CardDescription>
                Take a clear photo of affected leaves or plants for accurate pest identification
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Image Upload Area */}
              <div
                className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center cursor-pointer hover:border-orange-400 transition-colors"
                onClick={() => fileInputRef.current?.click()}
              >
                {selectedImage ? (
                  <div className="space-y-4">
                    <div className="relative w-full h-64 rounded-lg overflow-hidden">
                      <Image
                        src={selectedImage || "/placeholder.svg"}
                        alt="Uploaded crop image"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <Button variant="outline" className="gap-2 bg-transparent">
                      <Upload className="w-4 h-4" />
                      Change Image
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="w-16 h-16 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center mx-auto">
                      <Camera className="w-8 h-8 text-orange-600 dark:text-orange-400" />
                    </div>
                    <div>
                      <p className="text-lg font-medium">Upload an image</p>
                      <p className="text-gray-600 dark:text-gray-400">Click to select or drag and drop</p>
                      <p className="text-sm text-gray-500 dark:text-gray-500 mt-2">
                        Supported formats: JPG, PNG, WebP (max 10MB)
                      </p>
                    </div>
                  </div>
                )}
              </div>

              <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />

              {/* Analysis Button */}
              <Button
                onClick={handleAnalyze}
                disabled={!selectedImage || isAnalyzing}
                className="w-full bg-orange-600 hover:bg-orange-700"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Analyze for Pests
                  </>
                )}
              </Button>

              {/* Analysis Progress */}
              {isAnalyzing && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>AI Analysis Progress</span>
                    <span>{analysisProgress}%</span>
                  </div>
                  <Progress value={analysisProgress} className="w-full" />
                  <p className="text-xs text-gray-600 dark:text-gray-400">
                    Processing image with advanced pest detection algorithms...
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Results Section */}
          <div className="space-y-6">
            {detectionResult ? (
              <>
                {/* Detection Summary */}
                <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2">
                        <Bug className="w-5 h-5 text-orange-600" />
                        Detection Results
                      </CardTitle>
                      <Badge className={getSeverityColor(detectionResult.severity)}>
                        {getSeverityIcon(detectionResult.severity)}
                        {detectionResult.severity} Risk
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h3 className="text-lg font-semibold text-orange-800 dark:text-orange-200">
                        {detectionResult.pest}
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Confidence: {detectionResult.confidence}%
                      </p>
                    </div>

                    <p className="text-gray-700 dark:text-gray-300">{detectionResult.description}</p>

                    <Alert className="border-orange-200 bg-orange-50 dark:bg-orange-950">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Time to Act:</strong> {detectionResult.timeToAct}
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>

                {/* Symptoms */}
                <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Eye className="w-5 h-5 text-blue-600" />
                      Symptoms to Look For
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {detectionResult.symptoms.map((symptom, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2 flex-shrink-0"></span>
                          <span className="text-gray-700 dark:text-gray-300">{symptom}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                {/* Treatment Options */}
                <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Leaf className="w-5 h-5 text-green-600" />
                      Treatment Recommendations
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Organic Treatment */}
                    <div>
                      <h4 className="font-semibold text-green-700 dark:text-green-300 mb-2">
                        Organic Treatment (Recommended)
                      </h4>
                      <ul className="space-y-1">
                        {detectionResult.treatment.organic.map((treatment, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <span className="w-1 h-1 bg-green-600 rounded-full mt-2 flex-shrink-0"></span>
                            <span className="text-gray-700 dark:text-gray-300">{treatment}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <Separator />

                    {/* Chemical Treatment */}
                    <div>
                      <h4 className="font-semibold text-yellow-700 dark:text-yellow-300 mb-2">
                        Chemical Treatment (If Severe)
                      </h4>
                      <ul className="space-y-1">
                        {detectionResult.treatment.chemical.map((treatment, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <span className="w-1 h-1 bg-yellow-600 rounded-full mt-2 flex-shrink-0"></span>
                            <span className="text-gray-700 dark:text-gray-300">{treatment}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <Separator />

                    {/* Preventive Measures */}
                    <div>
                      <h4 className="font-semibold text-blue-700 dark:text-blue-300 mb-2">Preventive Measures</h4>
                      <ul className="space-y-1">
                        {detectionResult.treatment.preventive.map((measure, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <span className="w-1 h-1 bg-blue-600 rounded-full mt-2 flex-shrink-0"></span>
                            <span className="text-gray-700 dark:text-gray-300">{measure}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>

                {/* Affected Crops */}
                <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-sm">Commonly Affected Crops</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {detectionResult.affectedCrops.map((crop, index) => (
                        <Badge key={index} variant="outline" className="bg-gray-50 dark:bg-gray-800">
                          {crop}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                <CardContent className="py-12 text-center">
                  <Bug className="w-12 h-12 text-orange-600 mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Ready to Analyze</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Upload an image of your crop to get AI-powered pest and disease detection results.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
