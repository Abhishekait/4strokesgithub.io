"use client"

import { useState } from "react"
import { useLanguage } from "@/contexts/language-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CreditCard, Percent, Clock, Upload, CheckCircle, Building, Tractor, Coins, ExternalLink } from "lucide-react"
import { toast } from "sonner"

export default function LoansPage() {
  const { t } = useLanguage()
  const [uploadedFiles, setUploadedFiles] = useState<Record<string, boolean>>({})
  const [applicationData, setApplicationData] = useState({
    name: "",
    phone: "",
    email: "",
    loanType: "",
    loanAmount: "",
    purpose: "",
    landArea: "",
    cropType: "",
    bankPreference: "",
  })

  const bankUrls: Record<string, string> = {
    SBI: "https://www.onlinesbi.sbi/",
    HDFC: "https://www.hdfcbank.com/",
    ICICI: "https://www.icicibank.com/",
    PNB: "https://www.pnbindia.in/",
    BOI: "https://www.bankofindia.co.in/",
    Canara: "https://canarabank.com/",
    BOB: "https://www.bankofbaroda.in/",
    Muthoot: "https://www.muthootfinance.com/",
    Manappuram: "https://www.manappuram.com/",
    "Mahindra Finance": "https://www.mahindrafinance.com/",
    TAFE: "https://www.tafe.com/",
    "John Deere": "https://www.deere.co.in/",
  }

  const loanSchemes = [
    {
      id: "kisan-credit-card",
      title: t("kisanCreditCard"),
      description: t("kisanCreditCardDesc"),
      rate: t("kisanCreditCardRate"),
      limit: t("kisanCreditCardLimit"),
      icon: CreditCard,
      color: "bg-blue-500",
      banks: ["SBI", "HDFC", "ICICI", "PNB", "BOI"],
      features: ["Revolving credit", "RuPay debit card", "Flexible repayment", "Crop insurance"],
    },
    {
      id: "crop-loan",
      title: t("cropLoan"),
      description: t("cropLoanDesc"),
      rate: "7-12% p.a.",
      limit: t("cropLoanTenure"),
      icon: Building,
      color: "bg-green-500",
      banks: ["SBI", "HDFC", "ICICI", "Canara", "BOB"],
      features: ["Short-term", "Seasonal crops", "Input financing", "Quick processing"],
    },
    {
      id: "farm-mechanization",
      title: t("farmMechanization"),
      description: t("farmMechanizationDesc"),
      rate: "8-14% p.a.",
      limit: t("farmMechanizationTenure"),
      icon: Tractor,
      color: "bg-orange-500",
      banks: ["SBI", "HDFC", "Mahindra Finance", "TAFE", "John Deere"],
      features: ["Equipment purchase", "Long tenure", "Subsidy available", "EMI options"],
    },
    {
      id: "gold-loan",
      title: t("goldLoan"),
      description: t("goldLoanDesc"),
      rate: "9-15% p.a.",
      limit: "Up to 75% of gold value",
      icon: Coins,
      color: "bg-yellow-500",
      banks: ["SBI", "HDFC", "ICICI", "Muthoot", "Manappuram"],
      features: ["Quick approval", "Minimal documentation", "Flexible tenure", "Competitive rates"],
    },
  ]

  const handleBankNavigation = (bankName: string) => {
    const url = bankUrls[bankName]
    if (url) {
      window.open(url, "_blank", "noopener,noreferrer")
      toast.success(`Redirecting to ${bankName} website`)
    } else {
      toast.error("Bank website not available")
    }
  }

  const requiredDocuments = [
    { key: "aadhar", label: t("aadharCard"), required: true },
    { key: "pan", label: t("panCard"), required: true },
    { key: "land", label: t("landRecords"), required: true },
    { key: "bank", label: t("bankStatement"), required: true },
    { key: "income", label: t("incomeProof"), required: false },
    { key: "crop", label: t("cropDetails"), required: false },
  ]

  const handleFileUpload = (documentKey: string) => {
    // Simulate file upload
    setUploadedFiles((prev) => ({ ...prev, [documentKey]: true }))
    toast.success(t("fileUploaded"))
  }

  const handleSubmitApplication = () => {
    const requiredUploaded = requiredDocuments.filter((doc) => doc.required).every((doc) => uploadedFiles[doc.key])

    if (!requiredUploaded) {
      toast.error("Please upload all required documents")
      return
    }

    if (!applicationData.name || !applicationData.phone || !applicationData.loanType) {
      toast.error("Please fill all required fields")
      return
    }

    toast.success(t("applicationSubmitted"))
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
            <CreditCard className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">{t("loansCredit")}</h1>
            <p className="text-gray-600 dark:text-gray-400">{t("loansCreditDesc")}</p>
          </div>
        </div>
      </div>

      <Tabs defaultValue="schemes" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="schemes">Loan Schemes</TabsTrigger>
          <TabsTrigger value="apply">Apply for Loan</TabsTrigger>
        </TabsList>

        <TabsContent value="schemes" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {loanSchemes.map((scheme) => {
              const Icon = scheme.icon
              return (
                <Card key={scheme.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 ${scheme.color} rounded-lg flex items-center justify-center`}>
                          <Icon className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <CardTitle className="text-xl">{scheme.title}</CardTitle>
                          <div className="flex gap-2 mt-1">
                            <Badge variant="secondary">
                              <Percent className="w-3 h-3 mr-1" />
                              {scheme.rate}
                            </Badge>
                            <Badge variant="outline">
                              <Clock className="w-3 h-3 mr-1" />
                              {scheme.limit}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                    <CardDescription className="text-sm">{scheme.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-semibold text-sm text-gray-700 dark:text-gray-300 mb-2">Key Features</h4>
                        <ul className="space-y-1">
                          {scheme.features.map((feature, index) => (
                            <li
                              key={index}
                              className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-2"
                            >
                              <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-semibold text-sm text-gray-700 dark:text-gray-300 mb-2">Available Banks</h4>
                        <div className="flex flex-wrap gap-1">
                          {scheme.banks.map((bank, index) => (
                            <Badge
                              key={index}
                              variant="outline"
                              className="text-xs cursor-pointer hover:bg-blue-50 hover:border-blue-300 transition-colors"
                              onClick={() => handleBankNavigation(bank)}
                            >
                              {bank}
                              <ExternalLink className="w-2 h-2 ml-1" />
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="text-sm text-gray-600 dark:text-gray-400">Choose a bank to apply:</p>
                        <div className="grid grid-cols-1 gap-2">
                          {scheme.banks.map((bank, index) => (
                            <Button
                              key={index}
                              variant="outline"
                              className="w-full justify-between hover:bg-blue-50 hover:border-blue-300 bg-transparent"
                              onClick={() => handleBankNavigation(bank)}
                            >
                              <span>Apply with {bank}</span>
                              <ExternalLink className="w-4 h-4" />
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="apply" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Application Form */}
            <Card>
              <CardHeader>
                <CardTitle>Loan Application Form</CardTitle>
                <CardDescription>Fill in your details to apply for a loan</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Full Name *</Label>
                    <Input
                      id="name"
                      value={applicationData.name}
                      onChange={(e) => setApplicationData((prev) => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter your full name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      value={applicationData.phone}
                      onChange={(e) => setApplicationData((prev) => ({ ...prev, phone: e.target.value }))}
                      placeholder="Enter phone number"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={applicationData.email}
                    onChange={(e) => setApplicationData((prev) => ({ ...prev, email: e.target.value }))}
                    placeholder="Enter email address"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="loanType">Loan Type *</Label>
                    <Select
                      value={applicationData.loanType}
                      onValueChange={(value) => setApplicationData((prev) => ({ ...prev, loanType: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select loan type" />
                      </SelectTrigger>
                      <SelectContent>
                        {loanSchemes.map((scheme) => (
                          <SelectItem key={scheme.id} value={scheme.id}>
                            {scheme.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="loanAmount">Loan Amount (₹)</Label>
                    <Input
                      id="loanAmount"
                      value={applicationData.loanAmount}
                      onChange={(e) => setApplicationData((prev) => ({ ...prev, loanAmount: e.target.value }))}
                      placeholder="Enter loan amount"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="landArea">Land Area (acres)</Label>
                    <Input
                      id="landArea"
                      value={applicationData.landArea}
                      onChange={(e) => setApplicationData((prev) => ({ ...prev, landArea: e.target.value }))}
                      placeholder="Enter land area"
                    />
                  </div>
                  <div>
                    <Label htmlFor="cropType">Primary Crop</Label>
                    <Input
                      id="cropType"
                      value={applicationData.cropType}
                      onChange={(e) => setApplicationData((prev) => ({ ...prev, cropType: e.target.value }))}
                      placeholder="Enter primary crop"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="bankPreference">Preferred Bank</Label>
                  <Select
                    value={applicationData.bankPreference}
                    onValueChange={(value) => setApplicationData((prev) => ({ ...prev, bankPreference: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select preferred bank" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sbi">State Bank of India</SelectItem>
                      <SelectItem value="hdfc">HDFC Bank</SelectItem>
                      <SelectItem value="icici">ICICI Bank</SelectItem>
                      <SelectItem value="pnb">Punjab National Bank</SelectItem>
                      <SelectItem value="boi">Bank of India</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="purpose">Purpose of Loan</Label>
                  <Textarea
                    id="purpose"
                    value={applicationData.purpose}
                    onChange={(e) => setApplicationData((prev) => ({ ...prev, purpose: e.target.value }))}
                    placeholder="Describe the purpose of the loan"
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Document Upload */}
            <Card>
              <CardHeader>
                <CardTitle>{t("uploadDocuments")}</CardTitle>
                <CardDescription>{t("documentsRequired")}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {requiredDocuments.map((doc) => (
                  <div key={doc.key} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          uploadedFiles[doc.key] ? "bg-green-100 text-green-600" : "bg-gray-100 text-gray-400"
                        }`}
                      >
                        {uploadedFiles[doc.key] ? <CheckCircle className="w-4 h-4" /> : <Upload className="w-4 h-4" />}
                      </div>
                      <div>
                        <p className="font-medium text-sm">{doc.label}</p>
                        {doc.required && (
                          <Badge variant="destructive" className="text-xs">
                            Required
                          </Badge>
                        )}
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant={uploadedFiles[doc.key] ? "outline" : "default"}
                      onClick={() => handleFileUpload(doc.key)}
                    >
                      {uploadedFiles[doc.key] ? "Uploaded" : t("uploadFile")}
                    </Button>
                  </div>
                ))}

                <Button className="w-full mt-6" size="lg" onClick={handleSubmitApplication}>
                  {t("submitApplication")}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
