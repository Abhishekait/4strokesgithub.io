"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  TrendingUp,
  TrendingDown,
  ArrowLeft,
  Search,
  MapPin,
  BarChart3,
  Bell,
  Target,
  Loader2,
  IndianRupee,
  Wheat,
} from "lucide-react"
import Link from "next/link"

interface MarketPrice {
  crop: string
  currentPrice: number
  previousPrice: number
  change: number
  changePercent: number
  unit: string
  market: string
  lastUpdated: string
  trend: "up" | "down" | "stable"
  volume: number
  quality: string
}

interface PriceAlert {
  id: string
  crop: string
  targetPrice: number
  currentPrice: number
  type: "above" | "below"
  isActive: boolean
}

export default function MarketPage() {
  const [marketPrices, setMarketPrices] = useState<MarketPrice[]>([])
  const [priceAlerts, setPriceAlerts] = useState<PriceAlert[]>([])
  const [selectedMarket, setSelectedMarket] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    setTimeout(() => {
      const mockPrices: MarketPrice[] = [
        {
          crop: "धान (Rice)",
          currentPrice: 2850,
          previousPrice: 2750,
          change: 100,
          changePercent: 3.6,
          unit: "प्रति क्विंटल",
          market: "दिल्ली मंडी",
          lastUpdated: "2 घंटे पहले",
          trend: "up",
          volume: 1250,
          quality: "ग्रेड A",
        },
        {
          crop: "गेहूं (Wheat)",
          currentPrice: 2200,
          previousPrice: 2250,
          change: -50,
          changePercent: -2.2,
          unit: "प्रति क्विंटल",
          market: "पंजाब मंडी",
          lastUpdated: "1 घंटा पहले",
          trend: "down",
          volume: 2100,
          quality: "ग्रेड A",
        },
        {
          crop: "कपास (Cotton)",
          currentPrice: 6500,
          previousPrice: 6200,
          change: 300,
          changePercent: 4.8,
          unit: "प्रति क्विंटल",
          market: "गुजरात मंडी",
          lastUpdated: "45 मिनट पहले",
          trend: "up",
          volume: 850,
          quality: "ग्रेड A",
        },
        {
          crop: "प्याज (Onion)",
          currentPrice: 1800,
          previousPrice: 1900,
          change: -100,
          changePercent: -5.3,
          unit: "प्रति क्विंटल",
          market: "नासिक मंडी",
          lastUpdated: "30 मिनट पहले",
          trend: "down",
          volume: 1500,
          quality: "ग्रेड A",
        },
        {
          crop: "आलू (Potato)",
          currentPrice: 1200,
          previousPrice: 1150,
          change: 50,
          changePercent: 4.3,
          unit: "प्रति क्विंटल",
          market: "UP मंडी",
          lastUpdated: "1 घंटा पहले",
          trend: "up",
          volume: 3200,
          quality: "ग्रेड A",
        },
        {
          crop: "गन्ना (Sugarcane)",
          currentPrice: 350,
          previousPrice: 340,
          change: 10,
          changePercent: 2.9,
          unit: "प्रति क्विंटल",
          market: "महाराष्ट्र मंडी",
          lastUpdated: "2 घंटे पहले",
          trend: "up",
          volume: 5000,
          quality: "ग्रेड A",
        },
        {
          crop: "सोयाबीन (Soybean)",
          currentPrice: 4200,
          previousPrice: 4100,
          change: 100,
          changePercent: 2.4,
          unit: "प्रति क्विंटल",
          market: "MP मंडी",
          lastUpdated: "1.5 घंटे पहले",
          trend: "up",
          volume: 1800,
          quality: "ग्रेड A",
        },
        {
          crop: "चना (Chickpea)",
          currentPrice: 5800,
          previousPrice: 5650,
          change: 150,
          changePercent: 2.7,
          unit: "प्रति क्विंटल",
          market: "राजस्थान मंडी",
          lastUpdated: "3 घंटे पहले",
          trend: "up",
          volume: 950,
          quality: "ग्रेड A",
        },
        {
          crop: "हल्दी (Turmeric)",
          currentPrice: 8500,
          previousPrice: 8200,
          change: 300,
          changePercent: 3.7,
          unit: "प्रति क्विंटल",
          market: "तमिलनाडु मंडी",
          lastUpdated: "4 घंटे पहले",
          trend: "up",
          volume: 650,
          quality: "ग्रेड A",
        },
        {
          crop: "मिर्च (Chilli)",
          currentPrice: 12000,
          previousPrice: 11500,
          change: 500,
          changePercent: 4.3,
          unit: "प्रति क्विंटल",
          market: "आंध्र प्रदेश मंडी",
          lastUpdated: "2.5 घंटे पहले",
          trend: "up",
          volume: 420,
          quality: "ग्रेड A",
        },
        {
          crop: "बाजरा (Pearl Millet)",
          currentPrice: 2100,
          previousPrice: 2050,
          change: 50,
          changePercent: 2.4,
          unit: "प्रति क्विंटल",
          market: "राजस्थान मंडी",
          lastUpdated: "1 घंटा पहले",
          trend: "up",
          volume: 1100,
          quality: "ग्रेड A",
        },
        {
          crop: "ज्वार (Sorghum)",
          currentPrice: 2300,
          previousPrice: 2280,
          change: 20,
          changePercent: 0.9,
          unit: "प्रति क्विंटल",
          market: "महाराष्ट्र मंडी",
          lastUpdated: "2 घंटे पहले",
          trend: "stable",
          volume: 1350,
          quality: "ग्रेड A",
        },
      ]

      const mockAlerts: PriceAlert[] = [
        {
          id: "1",
          crop: "धान (Rice)",
          targetPrice: 2800,
          currentPrice: 2850,
          type: "above",
          isActive: true,
        },
        {
          id: "2",
          crop: "कपास (Cotton)",
          targetPrice: 6000,
          currentPrice: 6500,
          type: "above",
          isActive: true,
        },
      ]

      setMarketPrices(mockPrices)
      setPriceAlerts(mockAlerts)
      setIsLoading(false)
    }, 2000)
  }, [])

  const filteredPrices = marketPrices.filter((price) => {
    const matchesSearch = price.crop.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesMarket = selectedMarket === "all" || price.market.includes(selectedMarket)
    return matchesSearch && matchesMarket
  })

  const getTrendIcon = (trend: string, changePercent: number) => {
    if (trend === "up") {
      return <TrendingUp className="w-4 h-4 text-green-600" />
    } else if (trend === "down") {
      return <TrendingDown className="w-4 h-4 text-red-600" />
    }
    return <BarChart3 className="w-4 h-4 text-gray-600" />
  }

  const getTrendColor = (changePercent: number) => {
    if (changePercent > 0) return "text-green-600"
    if (changePercent < 0) return "text-red-600"
    return "text-gray-600"
  }

  const getQualityColor = (quality: string) => {
    switch (quality) {
      case "ग्रेड A":
        return "bg-green-100 text-green-800 border-green-300"
      case "ग्रेड B":
        return "bg-yellow-100 text-yellow-800 border-yellow-300"
      case "ग्रेड C":
        return "bg-orange-100 text-orange-800 border-orange-300"
      default:
        return "bg-gray-100 text-gray-800 border-gray-300"
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-violet-50 to-pink-50 dark:from-purple-950 dark:via-violet-950 dark:to-pink-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-violet-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Loader2 className="w-8 h-8 text-white animate-spin" />
          </div>
          <p className="text-lg font-medium text-purple-800 dark:text-purple-200">बाज़ार डेटा लोड हो रहा है...</p>
          <p className="text-sm text-purple-600 dark:text-purple-400">कृपया प्रतीक्षा करें</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen relative">
      <div
        className="absolute inset-0 opacity-5 dark:opacity-10"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23059669' fillOpacity='0.3'%3E%3Cpath d='M20 20c0-5.5-4.5-10-10-10s-10 4.5-10 10 4.5 10 10 10 10-4.5 10-10zm10 0c0 5.5 4.5 10 10 10s10-4.5 10-10-4.5-10-10-10-10 4.5-10 10z'/%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />

      <div className="relative bg-gradient-to-br from-purple-50 via-violet-50 to-pink-50 dark:from-purple-950 dark:via-violet-950 dark:to-pink-950">
        {/* Header */}
        <header className="bg-white/90 dark:bg-gray-900/90 backdrop-blur-md border-b border-purple-200 dark:border-purple-800 shadow-sm">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="sm" className="gap-2 hover:bg-purple-100 dark:hover:bg-purple-900">
                  <ArrowLeft className="w-4 h-4" />
                  वापस
                </Button>
              </Link>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-violet-600 rounded-xl flex items-center justify-center shadow-lg">
                  <IndianRupee className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-800 to-violet-700 bg-clip-text text-transparent dark:from-purple-200 dark:to-violet-300">
                    बाज़ार भाव
                  </h1>
                  <p className="text-sm text-purple-600 dark:text-purple-400 font-medium">लाइव मूल्य ट्रैकिंग</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className="container mx-auto px-4 py-8">
          {/* Price Alerts */}
          {priceAlerts.length > 0 && (
            <div className="mb-8 space-y-4">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <Bell className="w-6 h-6 text-orange-600" />
                मूल्य अलर्ट
              </h2>
              {priceAlerts.map((alert) => (
                <Alert
                  key={alert.id}
                  className="border-green-500 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950"
                >
                  <Bell className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800 dark:text-green-200">
                    <strong>{alert.crop}</strong> आपके लक्षित मूल्य ₹{alert.targetPrice} तक पहुंच गया है! वर्तमान मूल्य: ₹
                    {alert.currentPrice}
                  </AlertDescription>
                </Alert>
              ))}
            </div>
          )}

          <Tabs defaultValue="prices" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3 bg-white/80 dark:bg-gray-800/80">
              <TabsTrigger value="prices">लाइव मूल्य</TabsTrigger>
              <TabsTrigger value="trends">मूल्य रुझान</TabsTrigger>
              <TabsTrigger value="alerts">मूल्य अलर्ट</TabsTrigger>
            </TabsList>

            <TabsContent value="prices" className="space-y-6">
              {/* Filters */}
              <Card className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border-purple-200 dark:border-purple-800">
                <CardContent className="p-4">
                  <div className="flex flex-col md:flex-row gap-4">
                    <div className="flex-1">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                        <Input
                          placeholder="फसल खोजें..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-10"
                        />
                      </div>
                    </div>
                    <Select value={selectedMarket} onValueChange={setSelectedMarket}>
                      <SelectTrigger className="w-full md:w-48">
                        <SelectValue placeholder="मंडी चुनें" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">सभी मंडियां</SelectItem>
                        <SelectItem value="दिल्ली">दिल्ली मंडी</SelectItem>
                        <SelectItem value="मुंबई">मुंबई मंडी</SelectItem>
                        <SelectItem value="पंजाब">पंजाब मंडी</SelectItem>
                        <SelectItem value="नासिक">नासिक मंडी</SelectItem>
                        <SelectItem value="UP">UP मंडी</SelectItem>
                        <SelectItem value="महाराष्ट्र">महाराष्ट्र मंडी</SelectItem>
                        <SelectItem value="गुजरात">गुजरात मंडी</SelectItem>
                        <SelectItem value="राजस्थान">राजस्थान मंडी</SelectItem>
                        <SelectItem value="MP">MP मंडी</SelectItem>
                        <SelectItem value="तमिलनाडु">तमिलनाडु मंडी</SelectItem>
                        <SelectItem value="आंध्र प्रदेश">आंध्र प्रदेश मंडी</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              {/* Price Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPrices.map((price, index) => (
                  <Card
                    key={index}
                    className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm hover:shadow-xl transition-all duration-300 border-purple-200 dark:border-purple-800 hover:border-purple-300 dark:hover:border-purple-700"
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg flex items-center gap-2">
                          <Wheat className="w-5 h-5 text-purple-600" />
                          {price.crop}
                        </CardTitle>
                        <Badge className={getQualityColor(price.quality)}>{price.quality}</Badge>
                      </div>
                      <CardDescription className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {price.market}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-2xl font-bold text-purple-700 dark:text-purple-300">
                            ₹{price.currentPrice.toLocaleString()}
                          </p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{price.unit}</p>
                        </div>
                        <div className="text-right">
                          <div className={`flex items-center gap-1 ${getTrendColor(price.changePercent)}`}>
                            {getTrendIcon(price.trend, price.changePercent)}
                            <span className="font-medium">
                              {price.changePercent > 0 ? "+" : ""}
                              {price.changePercent.toFixed(1)}%
                            </span>
                          </div>
                          <p className={`text-sm ${getTrendColor(price.change)}`}>
                            {price.change > 0 ? "+" : ""}₹{price.change}
                          </p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600 dark:text-gray-400">मात्रा</p>
                          <p className="font-medium">{price.volume.toLocaleString()} क्विंटल</p>
                        </div>
                        <div>
                          <p className="text-gray-600 dark:text-gray-400">अपडेट</p>
                          <p className="font-medium">{price.lastUpdated}</p>
                        </div>
                      </div>

                      <Button
                        className="w-full bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-700 hover:to-violet-700 shadow-lg"
                        size="sm"
                      >
                        <Target className="w-4 h-4 mr-2" />
                        मूल्य अलर्ट सेट करें
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="trends" className="space-y-6">
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-purple-600" />
                    Price Trends Analysis
                  </CardTitle>
                  <CardDescription>Historical price movements and market insights</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {/* Top Gainers */}
                    <div>
                      <h3 className="font-semibold text-green-700 dark:text-green-300 mb-3">Top Gainers Today</h3>
                      <div className="space-y-2">
                        {filteredPrices
                          .filter((p) => p.changePercent > 0)
                          .sort((a, b) => b.changePercent - a.changePercent)
                          .slice(0, 3)
                          .map((price, index) => (
                            <div
                              key={index}
                              className="flex items-center justify-between p-3 rounded-lg bg-green-50 dark:bg-green-950"
                            >
                              <div>
                                <p className="font-medium">{price.crop}</p>
                                <p className="text-sm text-gray-600 dark:text-gray-400">
                                  ₹{price.currentPrice} {price.unit}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className="font-bold text-green-600">+{price.changePercent.toFixed(1)}%</p>
                                <p className="text-sm text-green-600">+₹{price.change}</p>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>

                    {/* Top Losers */}
                    <div>
                      <h3 className="font-semibold text-red-700 dark:text-red-300 mb-3">Top Losers Today</h3>
                      <div className="space-y-2">
                        {filteredPrices
                          .filter((p) => p.changePercent < 0)
                          .sort((a, b) => a.changePercent - b.changePercent)
                          .slice(0, 3)
                          .map((price, index) => (
                            <div
                              key={index}
                              className="flex items-center justify-between p-3 rounded-lg bg-red-50 dark:bg-red-950"
                            >
                              <div>
                                <p className="font-medium">{price.crop}</p>
                                <p className="text-sm text-gray-600 dark:text-gray-400">
                                  ₹{price.currentPrice} {price.unit}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className="font-bold text-red-600">{price.changePercent.toFixed(1)}%</p>
                                <p className="text-sm text-red-600">₹{price.change}</p>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="alerts" className="space-y-6">
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="w-5 h-5 text-purple-600" />
                    Price Alert Management
                  </CardTitle>
                  <CardDescription>Set up alerts to get notified when prices reach your target</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Alert className="border-blue-500 bg-blue-50 dark:bg-blue-950">
                      <Bell className="h-4 w-4" />
                      <AlertDescription>
                        Price alerts help you make informed selling decisions. Set target prices for your crops and get
                        notified when market conditions are favorable.
                      </AlertDescription>
                    </Alert>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select crop" />
                        </SelectTrigger>
                        <SelectContent>
                          {marketPrices.map((price) => (
                            <SelectItem key={price.crop} value={price.crop.toLowerCase()}>
                              {price.crop}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Input placeholder="Target price (₹)" type="number" />
                      <Button className="bg-purple-600 hover:bg-purple-700">
                        <Bell className="w-4 h-4 mr-2" />
                        Set Alert
                      </Button>
                    </div>

                    {/* Active Alerts */}
                    {priceAlerts.length > 0 && (
                      <div className="mt-6">
                        <h3 className="font-semibold mb-3">Active Alerts</h3>
                        <div className="space-y-2">
                          {priceAlerts.map((alert) => (
                            <div
                              key={alert.id}
                              className="flex items-center justify-between p-3 rounded-lg border border-gray-200 dark:border-gray-700"
                            >
                              <div>
                                <p className="font-medium">{alert.crop}</p>
                                <p className="text-sm text-gray-600 dark:text-gray-400">
                                  Alert when price goes {alert.type} ₹{alert.targetPrice}
                                </p>
                              </div>
                              <div className="flex items-center gap-2">
                                <Badge variant={alert.isActive ? "default" : "secondary"}>
                                  {alert.isActive ? "Active" : "Inactive"}
                                </Badge>
                                <Button variant="outline" size="sm">
                                  Remove
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}
