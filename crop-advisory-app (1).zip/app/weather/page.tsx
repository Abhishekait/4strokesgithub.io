"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Cloud,
  Sun,
  CloudRain,
  Thermometer,
  Droplets,
  Wind,
  Eye,
  ArrowLeft,
  AlertTriangle,
  TrendingUp,
  Calendar,
  MapPin,
} from "lucide-react"
import Link from "next/link"

interface WeatherData {
  current: {
    temperature: number
    humidity: number
    windSpeed: number
    visibility: number
    condition: string
    icon: string
    pressure: number
    uvIndex: number
  }
  forecast: Array<{
    date: string
    high: number
    low: number
    condition: string
    icon: string
    precipitation: number
    windSpeed: number
  }>
  alerts: Array<{
    type: "warning" | "advisory" | "watch"
    title: string
    description: string
    severity: "low" | "medium" | "high"
  }>
  farmingInsights: Array<{
    activity: string
    recommendation: string
    timing: string
    priority: "low" | "medium" | "high"
  }>
}

export default function WeatherPage() {
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null)
  const [location, setLocation] = useState("Current Location")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate weather API call
    setTimeout(() => {
      const mockWeatherData: WeatherData = {
        current: {
          temperature: 28,
          humidity: 65,
          windSpeed: 12,
          visibility: 10,
          condition: "Partly Cloudy",
          icon: "partly-cloudy",
          pressure: 1013,
          uvIndex: 6,
        },
        forecast: [
          {
            date: "Today",
            high: 32,
            low: 24,
            condition: "Sunny",
            icon: "sunny",
            precipitation: 0,
            windSpeed: 8,
          },
          {
            date: "Tomorrow",
            high: 29,
            low: 22,
            condition: "Light Rain",
            icon: "light-rain",
            precipitation: 15,
            windSpeed: 15,
          },
          {
            date: "Day 3",
            high: 26,
            low: 20,
            condition: "Heavy Rain",
            icon: "heavy-rain",
            precipitation: 45,
            windSpeed: 22,
          },
          {
            date: "Day 4",
            high: 30,
            low: 23,
            condition: "Cloudy",
            icon: "cloudy",
            precipitation: 5,
            windSpeed: 10,
          },
          {
            date: "Day 5",
            high: 33,
            low: 25,
            condition: "Sunny",
            icon: "sunny",
            precipitation: 0,
            windSpeed: 7,
          },
        ],
        alerts: [
          {
            type: "warning",
            title: "Heavy Rain Expected",
            description: "Heavy rainfall expected in 2 days. Consider postponing field activities.",
            severity: "high",
          },
          {
            type: "advisory",
            title: "High UV Index",
            description: "UV index will be high today. Protect yourself and crops from sun damage.",
            severity: "medium",
          },
        ],
        farmingInsights: [
          {
            activity: "Irrigation",
            recommendation: "Skip irrigation for next 2 days due to expected rainfall",
            timing: "Next 48 hours",
            priority: "high",
          },
          {
            activity: "Pesticide Application",
            recommendation: "Apply pesticides today before rain arrives",
            timing: "Today before 6 PM",
            priority: "high",
          },
          {
            activity: "Harvesting",
            recommendation: "Good conditions for harvesting mature crops",
            timing: "Today and tomorrow morning",
            priority: "medium",
          },
          {
            activity: "Planting",
            recommendation: "Wait for rain to pass before planting new seeds",
            timing: "After Day 3",
            priority: "low",
          },
        ],
      }
      setWeatherData(mockWeatherData)
      setIsLoading(false)
    }, 1500)
  }, [])

  const getWeatherIcon = (condition: string) => {
    switch (condition.toLowerCase()) {
      case "sunny":
        return <Sun className="w-8 h-8 text-yellow-500" />
      case "partly-cloudy":
        return <Cloud className="w-8 h-8 text-gray-500" />
      case "cloudy":
        return <Cloud className="w-8 h-8 text-gray-600" />
      case "light-rain":
        return <CloudRain className="w-8 h-8 text-blue-500" />
      case "heavy-rain":
        return <CloudRain className="w-8 h-8 text-blue-700" />
      default:
        return <Sun className="w-8 h-8 text-yellow-500" />
    }
  }

  const getAlertColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "border-red-500 bg-red-50 dark:bg-red-950"
      case "medium":
        return "border-yellow-500 bg-yellow-50 dark:bg-yellow-950"
      case "low":
        return "border-blue-500 bg-blue-50 dark:bg-blue-950"
      default:
        return "border-gray-500 bg-gray-50 dark:bg-gray-950"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800 border-red-300"
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-300"
      case "low":
        return "bg-green-100 text-green-800 border-green-300"
      default:
        return "bg-gray-100 text-gray-800 border-gray-300"
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 dark:from-blue-950 dark:to-green-950 flex items-center justify-center">
        <div className="text-center">
          <Cloud className="w-12 h-12 text-blue-600 mx-auto mb-4 animate-pulse" />
          <p className="text-lg font-medium">Loading weather data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 dark:from-blue-950 dark:to-green-950">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-blue-200 dark:border-blue-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Back
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Cloud className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-blue-800 dark:text-blue-200">Weather Insights</h1>
                <p className="text-sm text-blue-600 dark:text-blue-400 flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  {location}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Weather Alerts */}
        {weatherData?.alerts && weatherData.alerts.length > 0 && (
          <div className="mb-8 space-y-4">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Weather Alerts</h2>
            {weatherData.alerts.map((alert, index) => (
              <Alert key={index} className={getAlertColor(alert.severity)}>
                <AlertTriangle className="h-4 w-4" />
                <div>
                  <h4 className="font-semibold">{alert.title}</h4>
                  <AlertDescription>{alert.description}</AlertDescription>
                </div>
              </Alert>
            ))}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Current Weather */}
          <div className="lg:col-span-1">
            <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Thermometer className="w-5 h-5 text-blue-600" />
                  Current Weather
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-center">
                  {getWeatherIcon(weatherData?.current.condition || "")}
                  <p className="text-4xl font-bold mt-2">{weatherData?.current.temperature}°C</p>
                  <p className="text-gray-600 dark:text-gray-400">{weatherData?.current.condition}</p>
                </div>

                <Separator />

                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2">
                    <Droplets className="w-4 h-4 text-blue-500" />
                    <div>
                      <p className="text-sm font-medium">Humidity</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{weatherData?.current.humidity}%</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Wind className="w-4 h-4 text-gray-500" />
                    <div>
                      <p className="text-sm font-medium">Wind</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{weatherData?.current.windSpeed} km/h</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Eye className="w-4 h-4 text-green-500" />
                    <div>
                      <p className="text-sm font-medium">Visibility</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{weatherData?.current.visibility} km</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Sun className="w-4 h-4 text-orange-500" />
                    <div>
                      <p className="text-sm font-medium">UV Index</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{weatherData?.current.uvIndex}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 5-Day Forecast */}
          <div className="lg:col-span-2">
            <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  5-Day Forecast
                </CardTitle>
                <CardDescription>Plan your farming activities ahead</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {weatherData?.forecast.map((day, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-4 rounded-lg bg-gray-50 dark:bg-gray-800"
                    >
                      <div className="flex items-center gap-4">
                        {getWeatherIcon(day.condition)}
                        <div>
                          <p className="font-medium">{day.date}</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{day.condition}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">
                          {day.high}° / {day.low}°
                        </p>
                        <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                          <span className="flex items-center gap-1">
                            <Droplets className="w-3 h-3" />
                            {day.precipitation}%
                          </span>
                          <span className="flex items-center gap-1">
                            <Wind className="w-3 h-3" />
                            {day.windSpeed} km/h
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Farming Insights */}
        <div className="mt-8">
          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-green-600" />
                Farming Insights
              </CardTitle>
              <CardDescription>Weather-based recommendations for your farm activities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {weatherData?.farmingInsights.map((insight, index) => (
                  <div key={index} className="p-4 rounded-lg border border-gray-200 dark:border-gray-700">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{insight.activity}</h4>
                      <Badge className={getPriorityColor(insight.priority)}>{insight.priority} priority</Badge>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{insight.recommendation}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-500">Timing: {insight.timing}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
