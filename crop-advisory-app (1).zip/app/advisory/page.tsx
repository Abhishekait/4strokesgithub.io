"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Leaf, MapPin, Calendar, Thermometer, Zap, ArrowLeft, Loader2 } from "lucide-react"
import Link from "next/link"

interface CropRecommendation {
  crop: string
  suitability: "High" | "Medium" | "Low"
  reason: string
  plantingTime: string
  expectedYield: string
  tips: string[]
}

export default function CropAdvisoryPage() {
  const [formData, setFormData] = useState({
    location: "",
    soilType: "",
    cropType: "",
    farmSize: "",
    previousCrop: "",
    budget: "",
    additionalInfo: "",
  })
  const [recommendations, setRecommendations] = useState<CropRecommendation[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate AI processing
    setTimeout(() => {
      const mockRecommendations: CropRecommendation[] = [
        {
          crop: "Rice",
          suitability: "High",
          reason: "Excellent match for your clay soil and monsoon season timing",
          plantingTime: "June - July",
          expectedYield: "4-5 tons/hectare",
          tips: [
            "Use certified seeds for better yield",
            "Maintain water level at 2-3 inches",
            "Apply organic fertilizer before planting",
          ],
        },
        {
          crop: "Wheat",
          suitability: "Medium",
          reason: "Good option for winter season with proper irrigation",
          plantingTime: "November - December",
          expectedYield: "3-4 tons/hectare",
          tips: ["Ensure proper drainage", "Use nitrogen-rich fertilizer", "Monitor for rust diseases"],
        },
        {
          crop: "Sugarcane",
          suitability: "Low",
          reason: "Requires more water than available in your region",
          plantingTime: "February - March",
          expectedYield: "60-70 tons/hectare",
          tips: ["Consider drip irrigation", "High water requirement", "Long growing season needed"],
        },
      ]
      setRecommendations(mockRecommendations)
      setIsLoading(false)
    }, 2000)
  }

  const getSuitabilityColor = (suitability: string) => {
    switch (suitability) {
      case "High":
        return "bg-green-100 text-green-800 border-green-300"
      case "Medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-300"
      case "Low":
        return "bg-red-100 text-red-800 border-red-300"
      default:
        return "bg-gray-100 text-gray-800 border-gray-300"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 dark:from-green-950 dark:to-blue-950">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-green-200 dark:border-green-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Back
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
                <Leaf className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-green-800 dark:text-green-200">Crop Advisory</h1>
                <p className="text-sm text-green-600 dark:text-green-400">AI-Powered Recommendations</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Form */}
          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-green-600" />
                Farm Information
              </CardTitle>
              <CardDescription>
                Provide details about your farm to get personalized crop recommendations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="location">Location</Label>
                    <Input
                      id="location"
                      placeholder="Enter your location"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="farmSize">Farm Size (hectares)</Label>
                    <Input
                      id="farmSize"
                      placeholder="e.g., 2.5"
                      value={formData.farmSize}
                      onChange={(e) => setFormData({ ...formData, farmSize: e.target.value })}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="soilType">Soil Type</Label>
                    <Select
                      value={formData.soilType}
                      onValueChange={(value) => setFormData({ ...formData, soilType: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select soil type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="clay">Clay</SelectItem>
                        <SelectItem value="sandy">Sandy</SelectItem>
                        <SelectItem value="loamy">Loamy</SelectItem>
                        <SelectItem value="silt">Silt</SelectItem>
                        <SelectItem value="mixed">Mixed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cropType">Preferred Crop Category</Label>
                    <Select
                      value={formData.cropType}
                      onValueChange={(value) => setFormData({ ...formData, cropType: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select crop category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cereals">Cereals</SelectItem>
                        <SelectItem value="vegetables">Vegetables</SelectItem>
                        <SelectItem value="fruits">Fruits</SelectItem>
                        <SelectItem value="cash-crops">Cash Crops</SelectItem>
                        <SelectItem value="pulses">Pulses</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="previousCrop">Previous Crop</Label>
                    <Input
                      id="previousCrop"
                      placeholder="What did you grow last season?"
                      value={formData.previousCrop}
                      onChange={(e) => setFormData({ ...formData, previousCrop: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="budget">Budget Range</Label>
                    <Select
                      value={formData.budget}
                      onValueChange={(value) => setFormData({ ...formData, budget: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select budget range" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low (&lt; 50,000)</SelectItem>
                        <SelectItem value="medium">Medium (50,000 - 2,00,000)</SelectItem>
                        <SelectItem value="high">High (&gt; 2,00,000)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="additionalInfo">Additional Information</Label>
                  <Textarea
                    id="additionalInfo"
                    placeholder="Any specific requirements, challenges, or goals?"
                    value={formData.additionalInfo}
                    onChange={(e) => setFormData({ ...formData, additionalInfo: e.target.value })}
                    rows={3}
                  />
                </div>

                <Button type="submit" className="w-full bg-green-600 hover:bg-green-700" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 mr-2" />
                      Get AI Recommendations
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Recommendations */}
          <div className="space-y-6">
            {recommendations.length > 0 && (
              <>
                <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Leaf className="w-5 h-5 text-green-600" />
                      Crop Recommendations
                    </CardTitle>
                    <CardDescription>Based on your farm conditions and preferences</CardDescription>
                  </CardHeader>
                </Card>

                {recommendations.map((rec, index) => (
                  <Card key={index} className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{rec.crop}</CardTitle>
                        <Badge className={getSuitabilityColor(rec.suitability)}>{rec.suitability} Suitability</Badge>
                      </div>
                      <CardDescription>{rec.reason}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-blue-600" />
                          <div>
                            <p className="text-sm font-medium">Planting Time</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{rec.plantingTime}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Thermometer className="w-4 h-4 text-orange-600" />
                          <div>
                            <p className="text-sm font-medium">Expected Yield</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{rec.expectedYield}</p>
                          </div>
                        </div>
                      </div>

                      <Separator />

                      <div>
                        <p className="text-sm font-medium mb-2">Farming Tips:</p>
                        <ul className="space-y-1">
                          {rec.tips.map((tip, tipIndex) => (
                            <li
                              key={tipIndex}
                              className="text-sm text-gray-600 dark:text-gray-400 flex items-start gap-2"
                            >
                              <span className="w-1 h-1 bg-green-600 rounded-full mt-2 flex-shrink-0"></span>
                              {tip}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </>
            )}

            {recommendations.length === 0 && !isLoading && (
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                <CardContent className="py-12 text-center">
                  <Leaf className="w-12 h-12 text-green-600 mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Ready for Recommendations</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Fill out the form to get personalized crop recommendations based on your farm conditions.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
