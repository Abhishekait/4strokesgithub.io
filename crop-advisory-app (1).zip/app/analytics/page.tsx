"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts"
import { ArrowLeft, Users, Activity, TrendingUp, Star, Download, Calendar, BarChart3 } from "lucide-react"
import Link from "next/link"

interface AnalyticsData {
  userStats: {
    totalUsers: number
    activeUsers: number
    newUsers: number
    retentionRate: number
  }
  featureUsage: Array<{
    feature: string
    usage: number
    growth: number
  }>
  userFeedback: Array<{
    rating: number
    count: number
  }>
  cropRecommendations: Array<{
    crop: string
    requests: number
  }>
  languageUsage: Array<{
    language: string
    users: number
    percentage: number
  }>
  weeklyActivity: Array<{
    day: string
    users: number
    sessions: number
  }>
}

export default function AnalyticsPage() {
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null)
  const [selectedPeriod, setSelectedPeriod] = useState("7d")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate analytics API call
    setTimeout(() => {
      const mockData: AnalyticsData = {
        userStats: {
          totalUsers: 12450,
          activeUsers: 8920,
          newUsers: 1250,
          retentionRate: 78.5,
        },
        featureUsage: [
          { feature: "Crop Advisory", usage: 4250, growth: 12.5 },
          { feature: "Weather", usage: 3890, growth: 8.2 },
          { feature: "Pest Detection", usage: 2150, growth: 15.8 },
          { feature: "Market Prices", usage: 3420, growth: 6.4 },
          { feature: "Voice Assistant", usage: 1680, growth: 22.1 },
        ],
        userFeedback: [
          { rating: 5, count: 5420 },
          { rating: 4, count: 3210 },
          { rating: 3, count: 890 },
          { rating: 2, count: 320 },
          { rating: 1, count: 160 },
        ],
        cropRecommendations: [
          { crop: "Rice", requests: 2850 },
          { crop: "Wheat", requests: 2100 },
          { crop: "Tomato", requests: 1890 },
          { crop: "Potato", requests: 1650 },
          { crop: "Onion", requests: 1420 },
          { crop: "Sugarcane", requests: 1180 },
        ],
        languageUsage: [
          { language: "Hindi", users: 3850, percentage: 30.9 },
          { language: "English", users: 2980, percentage: 23.9 },
          { language: "Bengali", users: 1890, percentage: 15.2 },
          { language: "Telugu", users: 1420, percentage: 11.4 },
          { language: "Tamil", users: 1180, percentage: 9.5 },
          { language: "Others", users: 1130, percentage: 9.1 },
        ],
        weeklyActivity: [
          { day: "Mon", users: 1250, sessions: 2100 },
          { day: "Tue", users: 1420, sessions: 2350 },
          { day: "Wed", users: 1680, sessions: 2890 },
          { day: "Thu", users: 1890, sessions: 3120 },
          { day: "Fri", users: 2100, sessions: 3450 },
          { day: "Sat", users: 1950, sessions: 3200 },
          { day: "Sun", users: 1580, sessions: 2680 },
        ],
      }
      setAnalyticsData(mockData)
      setIsLoading(false)
    }, 2000)
  }, [selectedPeriod])

  const COLORS = ["#10B981", "#3B82F6", "#F59E0B", "#EF4444", "#8B5CF6", "#06B6D4"]

  const calculateAverageRating = (feedback: Array<{ rating: number; count: number }>) => {
    const totalRatings = feedback.reduce((sum, item) => sum + item.count, 0)
    const weightedSum = feedback.reduce((sum, item) => sum + item.rating * item.count, 0)
    return (weightedSum / totalRatings).toFixed(1)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 dark:from-gray-950 dark:to-blue-950 flex items-center justify-center">
        <div className="text-center">
          <BarChart3 className="w-12 h-12 text-blue-600 mx-auto mb-4 animate-pulse" />
          <p className="text-lg font-medium">Loading analytics data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 dark:from-gray-950 dark:to-blue-950">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-gray-200 dark:border-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Back
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-blue-800 dark:text-blue-200">Analytics Dashboard</h1>
                <p className="text-sm text-blue-600 dark:text-blue-400">Usage Data & Insights</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Users</p>
                  <p className="text-2xl font-bold">{analyticsData?.userStats.totalUsers.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                  <Activity className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Active Users</p>
                  <p className="text-2xl font-bold">{analyticsData?.userStats.activeUsers.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">New Users</p>
                  <p className="text-2xl font-bold">{analyticsData?.userStats.newUsers.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center">
                  <Star className="w-6 h-6 text-orange-600 dark:text-orange-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Avg Rating</p>
                  <p className="text-2xl font-bold">
                    {analyticsData ? calculateAverageRating(analyticsData.userFeedback) : "0"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="usage" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="usage">Feature Usage</TabsTrigger>
            <TabsTrigger value="feedback">User Feedback</TabsTrigger>
            <TabsTrigger value="crops">Crop Requests</TabsTrigger>
            <TabsTrigger value="languages">Languages</TabsTrigger>
          </TabsList>

          <TabsContent value="usage" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Feature Usage Chart */}
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Feature Usage</CardTitle>
                  <CardDescription>Number of users per feature</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={analyticsData?.featureUsage}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="feature" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="usage" fill="#3B82F6" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Weekly Activity */}
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Weekly Activity</CardTitle>
                  <CardDescription>Daily active users and sessions</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={analyticsData?.weeklyActivity}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="users" stroke="#10B981" strokeWidth={2} />
                      <Line type="monotone" dataKey="sessions" stroke="#3B82F6" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Feature Growth */}
            <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Feature Growth Rates</CardTitle>
                <CardDescription>Month-over-month growth percentage</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analyticsData?.featureUsage.map((feature, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium">{feature.feature}</span>
                          <span className="text-sm text-green-600">+{feature.growth}%</span>
                        </div>
                        <Progress value={feature.growth} className="h-2" />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="feedback" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Rating Distribution */}
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Rating Distribution</CardTitle>
                  <CardDescription>User satisfaction ratings</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={analyticsData?.userFeedback}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ rating, count }) => `${rating}★ (${count})`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="count"
                      >
                        {analyticsData?.userFeedback.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Feedback Summary */}
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Feedback Summary</CardTitle>
                  <CardDescription>Overall user satisfaction metrics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-green-600 mb-2">
                      {analyticsData ? calculateAverageRating(analyticsData.userFeedback) : "0"}/5
                    </div>
                    <p className="text-gray-600 dark:text-gray-400">Average Rating</p>
                  </div>

                  <div className="space-y-3">
                    {analyticsData?.userFeedback.reverse().map((feedback, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <span className="text-sm font-medium w-8">{feedback.rating}★</span>
                        <Progress
                          value={
                            (feedback.count / analyticsData.userFeedback.reduce((sum, item) => sum + item.count, 0)) *
                            100
                          }
                          className="flex-1 h-2"
                        />
                        <span className="text-sm text-gray-600 dark:text-gray-400 w-16">{feedback.count}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="crops" className="space-y-6">
            <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Most Requested Crops</CardTitle>
                <CardDescription>Crop advisory requests by type</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={analyticsData?.cropRecommendations} layout="horizontal">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="crop" type="category" />
                    <Tooltip />
                    <Bar dataKey="requests" fill="#10B981" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="languages" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Language Distribution */}
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Language Usage</CardTitle>
                  <CardDescription>Distribution of users by language preference</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={analyticsData?.languageUsage}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ language, percentage }) => `${language} (${percentage}%)`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="users"
                      >
                        {analyticsData?.languageUsage.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Language Stats */}
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Language Statistics</CardTitle>
                  <CardDescription>Detailed breakdown by language</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analyticsData?.languageUsage.map((lang, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-gray-800"
                      >
                        <div>
                          <p className="font-medium">{lang.language}</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {lang.users.toLocaleString()} users
                          </p>
                        </div>
                        <Badge variant="outline">{lang.percentage}%</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Export Options */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="w-5 h-5" />
              Export Data
            </CardTitle>
            <CardDescription>Download analytics reports for further analysis</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <Button variant="outline" className="gap-2 bg-transparent">
                <Download className="w-4 h-4" />
                Export CSV
              </Button>
              <Button variant="outline" className="gap-2 bg-transparent">
                <Download className="w-4 h-4" />
                Export PDF Report
              </Button>
              <Button variant="outline" className="gap-2 bg-transparent">
                <Calendar className="w-4 h-4" />
                Schedule Report
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
