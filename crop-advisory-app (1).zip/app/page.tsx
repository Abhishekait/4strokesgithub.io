"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Cloud, Bug, TrendingUp, Mic, MapPin, BarChart3, Phone, Wheat, Sprout, CreditCard } from "lucide-react"
import Link from "next/link"
import { WeatherWidget } from "@/components/weather-widget"
import { MarketPriceWidget } from "@/components/market-price-widget"
import { PestDetectionWidget } from "@/components/pest-detection-widget"
import { VoiceAssistantWidget } from "@/components/voice-assistant-widget"
import { FeedbackWidget } from "@/components/feedback-widget"
import { LoanWidget } from "@/components/loan-widget"
import { useLanguage } from "@/contexts/language-context"
import { LanguageSwitcher } from "@/components/language-switcher"

export default function Dashboard() {
  const { t } = useLanguage()

  return (
    <div className="min-h-screen relative">
      <div
        className="absolute inset-0 opacity-5 dark:opacity-10"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23059669' fillOpacity='0.4'%3E%3Cpath d='M30 30c0-11.046-8.954-20-20-20s-20 8.954-20 20 8.954 20 20 20 20-8.954 20-20zm0 0c0 11.046 8.954 20 20 20s20-8.954 20-20-8.954-20-20-20-20 8.954-20 20z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />

      <div className="relative bg-gradient-to-br from-green-50 via-emerald-50 to-lime-50 dark:from-green-950 dark:via-emerald-950 dark:to-lime-950">
        {/* Header */}
        <header className="bg-white/90 dark:bg-gray-900/90 backdrop-blur-md border-b border-green-200 dark:border-green-800 shadow-sm">
          <div className="container mx-auto px-4 py-4 bg-[rgba(222,245,234,1)]">
            <div className="flex items-center justify-between bg-[rgba(232,249,235,1)]">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Wheat className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-green-800 to-emerald-700 bg-clip-text text-transparent dark:from-green-200 dark:to-emerald-300">
                    {t("appName")}
                  </h1>
                  <p className="text-sm text-green-600 dark:text-green-400 font-medium">{t("tagline")}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant="outline" className="bg-green-100 text-green-700 border-green-300 px-3 py-1">
                  <MapPin className="w-3 h-3 mr-1" />
                  {t("country")}
                </Badge>
                <LanguageSwitcher />
                <Button size="sm" variant="outline" className="gap-2 bg-white/50 hover:bg-white/80 border-green-300">
                  <Mic className="w-4 h-4" />
                  {t("voice")}
                </Button>
                <Link href="/analytics">
                  <Button size="sm" variant="outline" className="gap-2 bg-white/50 hover:bg-white/80 border-green-300">
                    <BarChart3 className="w-4 h-4" />
                    {t("analytics")}
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="container mx-auto px-4 py-8 text-gray-400 bg-[rgba(232,249,235,1)]">
          {/* Welcome Section */}
          <div className="mb-8 text-center">
            <h2 className="text-4xl font-bold bg-gradient-to-r from-green-800 to-emerald-700 bg-clip-text text-transparent dark:from-green-200 dark:to-emerald-300 mb-3">
              {t("welcome")}
            </h2>
            <p className="text-gray-700 dark:text-gray-300 text-lg max-w-2xl mx-auto">{t("welcomeDesc")}</p>
          </div>

          <Card className="mb-8 bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-950 dark:to-red-950 border-orange-200 dark:border-orange-800 bg-[rgba(250,200,200,1)]">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-full flex items-center justify-center shadow-lg">
                    <Phone className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-orange-800 dark:text-orange-200">{t("kisanCallCenter")}</h3>
                    <p className="text-orange-700 dark:text-orange-300">{t("freeSupport")}</p>
                    <div className="flex gap-4 mt-2">
                      <Badge className="bg-orange-600 text-white">📞 1800-180-1551</Badge>
                      <Badge className="bg-red-600 text-white">📞 1551 (BSNL)</Badge>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-orange-600 dark:text-orange-400 mb-2">{t("immediateHelp")}</p>
                  <Button className="bg-orange-600 hover:bg-orange-700 text-white">
                    <Phone className="w-4 h-4 mr-2" />
                    {t("callNow")}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <Card className="dark:bg-gray-800/80 backdrop-blur-sm border-green-200 dark:border-green-800 hover:shadow-lg transition-all duration-300 bg-[rgba(153,250,192,0.8)]">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-100 to-emerald-100 dark:from-green-900 dark:to-emerald-900 rounded-xl flex items-center justify-center">
                    <Sprout className="w-6 h-6 text-green-600 dark:text-green-400" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{t("soilHealth")}</p>
                    <p className="text-xl font-bold text-green-600 dark:text-green-400">{t("soilGood")}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="dark:bg-gray-800/80 backdrop-blur-sm border-blue-200 dark:border-blue-800 hover:shadow-lg transition-all duration-300 bg-[rgba(181,210,249,0.81)]">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-sky-100 dark:from-blue-900 dark:to-sky-900 rounded-xl flex items-center justify-center">
                    <Cloud className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{t("weather")}</p>
                    <p className="text-xl font-bold text-blue-600 dark:text-blue-400">{t("sunny")}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="dark:bg-gray-800/80 backdrop-blur-sm border-orange-200 dark:border-orange-800 hover:shadow-lg transition-all duration-300 bg-[rgba(250,186,153,0.8)]">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-orange-100 to-amber-100 dark:from-orange-900 dark:to-amber-900 rounded-xl flex items-center justify-center">
                    <Bug className="w-6 h-6 text-orange-600 dark:text-orange-400" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{t("pestRisk")}</p>
                    <p className="text-xl font-bold text-orange-600 dark:text-orange-400">{t("low")}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="dark:bg-gray-800/80 backdrop-blur-sm border-purple-200 dark:border-purple-800 hover:shadow-lg transition-all duration-300 bg-[rgba(205,183,245,0.81)]">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-100 to-violet-100 dark:from-purple-900 dark:to-violet-900 rounded-xl flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{t("market")}</p>
                    <p className="text-xl font-bold text-purple-600 dark:text-purple-400">{t("rising")}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Main Features */}
            <div className="lg:col-span-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Crop Advisory */}
                <Card className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm hover:shadow-xl transition-all duration-300 border-green-200 dark:border-green-800 hover:border-green-300 dark:hover:border-green-700">
                  <CardHeader>
                    <div className="flex items-center gap-3 bg-[rgba(204,250,204,1)]">
                      <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg">
                        <Wheat className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-green-800 dark:text-green-200">{t("cropAdvisory")}</CardTitle>
                        <CardDescription>{t("aiRecommendations")}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="dark:text-gray-300 mb-4 text-[rgba(81,155,56,1)]">{t("cropAdvisoryDesc")}</p>
                    <Link href="/advisory">
                      <Button className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 shadow-lg">
                        {t("getRecommendations")}
                      </Button>
                    </Link>
                  </CardContent>
                </Card>

                {/* Weather Alerts */}
                <Card className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm hover:shadow-xl transition-all duration-300 border-blue-200 dark:border-blue-800 hover:border-blue-300 dark:hover:border-blue-700">
                  <CardHeader>
                    <div className="flex items-center gap-3 bg-[rgba(196,195,243,1)]">
                      <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-sky-600 rounded-xl flex items-center justify-center shadow-lg">
                        <Cloud className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-blue-800 dark:text-blue-200">{t("weatherInfo")}</CardTitle>
                        <CardDescription>{t("realtimeAlerts")}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">{t("weatherDesc")}</p>
                    <Link href="/weather">
                      <Button className="w-full bg-gradient-to-r from-blue-600 to-sky-600 hover:from-blue-700 hover:to-sky-700 shadow-lg">
                        {t("viewWeather")}
                      </Button>
                    </Link>
                  </CardContent>
                </Card>

                {/* Pest Detection */}
                <Card className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm hover:shadow-xl transition-all duration-300 border-orange-200 dark:border-orange-800 hover:border-orange-300 dark:hover:border-orange-700">
                  <CardHeader>
                    <div className="flex items-center gap-3 bg-[rgba(255,196,181,1)]">
                      <div className="w-14 h-14 bg-gradient-to-br from-orange-500 to-amber-600 rounded-xl flex items-center justify-center shadow-lg">
                        <Bug className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-orange-800 dark:text-orange-200">{t("pestDetection")}</CardTitle>
                        <CardDescription>{t("aiImageAnalysis")}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">{t("pestDetectionDesc")}</p>
                    <Link href="/pest-detection">
                      <Button className="w-full bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 shadow-lg">
                        {t("scanCrop")}
                      </Button>
                    </Link>
                  </CardContent>
                </Card>

                {/* Market Prices */}
                <Card className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm hover:shadow-xl transition-all duration-300 border-purple-200 dark:border-purple-800 hover:border-purple-300 dark:hover:border-purple-700">
                  <CardHeader>
                    <div className="flex items-center gap-3 bg-[rgba(215,215,255,1)]">
                      <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-violet-600 rounded-xl flex items-center justify-center shadow-lg">
                        <TrendingUp className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-purple-800 dark:text-purple-200">{t("marketPrices")}</CardTitle>
                        <CardDescription>{t("livePriceTracking")}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">{t("marketPricesDesc")}</p>
                    <Link href="/market">
                      <Button className="w-full bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-700 hover:to-violet-700 shadow-lg">
                        {t("viewPrices")}
                      </Button>
                    </Link>
                  </CardContent>
                </Card>

                {/* Loan Services */}
                <Card className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm hover:shadow-xl transition-all duration-300 border-emerald-200 dark:border-emerald-800 hover:border-emerald-300 dark:hover:border-emerald-700">
                  <CardHeader>
                    <div className="flex items-center gap-3 bg-[rgba(204,255,229,1)]">
                      <div className="w-14 h-14 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg">
                        <CreditCard className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-emerald-800 dark:text-emerald-200">{t("loanServices")}</CardTitle>
                        <CardDescription>{t("quickLoanApproval")}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">{t("loanServicesDesc")}</p>
                    <Link href="/loans">
                      <Button className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 shadow-lg">
                        {t("applyForLoan")}
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Sidebar Widgets */}
            <div className="lg:col-span-1 space-y-6">
              <WeatherWidget compact />
              <MarketPriceWidget />
              <LoanWidget />
              <PestDetectionWidget />
              <VoiceAssistantWidget />
              <FeedbackWidget />
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
