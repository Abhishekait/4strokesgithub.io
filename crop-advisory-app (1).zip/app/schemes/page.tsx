"use client"

import { useLanguage } from "@/contexts/language-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Building2, IndianRupee, Shield, Leaf, Award, ExternalLink } from "lucide-react"

export default function SchemesPage() {
  const { t } = useLanguage()

  const schemes = [
    {
      id: "pm-kisan",
      title: t("pmKisan"),
      description: t("pmKisanDesc"),
      amount: t("pmKisanAmount"),
      details: t("pmKisanInstallments"),
      icon: IndianRupee,
      color: "bg-green-500",
      benefits: ["Direct Benefit Transfer", "No middleman", "Quarterly payments"],
      eligibility: ["Landholding farmer families", "Cultivable land ownership", "Valid Aadhar card"],
    },
    {
      id: "pm-fasal",
      title: t("pmFasal"),
      description: t("pmFasalDesc"),
      amount: t("pmFasalCoverage"),
      details: t("pmFasalRisks"),
      icon: Shield,
      color: "bg-blue-500",
      benefits: ["Crop loss coverage", "Natural calamity protection", "Affordable premium"],
      eligibility: ["All farmers", "Notified crops", "Timely enrollment"],
    },
    {
      id: "soil-health",
      title: t("soilHealthCard"),
      description: t("soilHealthCardDesc"),
      amount: t("soilHealthCardBenefit"),
      details: t("soilHealthCardRecommendations"),
      icon: Leaf,
      color: "bg-amber-500",
      benefits: ["Free soil testing", "Nutrient recommendations", "Improved productivity"],
      eligibility: ["All farmers", "Land ownership proof", "Soil samples required"],
    },
    {
      id: "organic-farming",
      title: t("organicFarming"),
      description: t("organicFarmingDesc"),
      amount: t("organicFarmingSupport"),
      details: t("organicFarmingCertification"),
      icon: Award,
      color: "bg-emerald-500",
      benefits: ["Financial assistance", "Organic certification", "Market linkage"],
      eligibility: ["Farmer groups", "Minimum 50 farmers", "Cluster approach"],
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center">
            <Building2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">{t("governmentSchemes")}</h1>
            <p className="text-gray-600 dark:text-gray-400">{t("governmentSchemesDesc")}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {schemes.map((scheme) => {
          const Icon = scheme.icon
          return (
            <Card key={scheme.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 ${scheme.color} rounded-lg flex items-center justify-center`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">{scheme.title}</CardTitle>
                      <Badge variant="secondary" className="mt-1">
                        {scheme.amount}
                      </Badge>
                    </div>
                  </div>
                </div>
                <CardDescription className="text-sm">{scheme.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-sm text-gray-700 dark:text-gray-300 mb-2">Key Benefits</h4>
                    <ul className="space-y-1">
                      {scheme.benefits.map((benefit, index) => (
                        <li key={index} className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-sm text-gray-700 dark:text-gray-300 mb-2">Eligibility</h4>
                    <ul className="space-y-1">
                      {scheme.eligibility.map((criteria, index) => (
                        <li key={index} className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
                          {criteria}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Button className="w-full bg-transparent" variant="outline">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Apply Online
                  </Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="mt-12 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-lg p-6">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">Need Help with Applications?</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Contact your nearest Common Service Center (CSC) or Agriculture Extension Officer for assistance
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-green-600 hover:bg-green-700">Find Nearest CSC</Button>
            <Button variant="outline">Contact Extension Officer</Button>
          </div>
        </div>
      </div>
    </div>
  )
}
