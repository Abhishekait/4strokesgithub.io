// Global state
let currentLanguage = localStorage.getItem("cropAdvisorLanguage") || "hi"
let currentSection = "dashboard"
let isListening = false

// Market data
const marketData = [
  { name: "गेहूं (Wheat)", nameEn: "Wheat", price: 2150, change: 2.5, location: "Delhi", trend: "up" },
  { name: "चावल (Rice)", nameEn: "Rice", price: 3200, change: -1.2, location: "Mumbai", trend: "down" },
  { name: "कपास (Cotton)", nameEn: "Cotton", price: 5800, change: 4.1, location: "Gujarat", trend: "up" },
  { name: "गन्ना (Sugarcane)", nameEn: "Sugarcane", price: 350, change: 1.8, location: "UP", trend: "up" },
  { name: "मक्का (Maize)", nameEn: "Maize", price: 1850, change: -0.5, location: "Bihar", trend: "down" },
  { name: "सोयाबीन (Soybean)", nameEn: "Soybean", price: 4200, change: 3.2, location: "MP", trend: "up" },
  { name: "चना (Chickpea)", nameEn: "Chickpea", price: 5500, change: 2.1, location: "Rajasthan", trend: "up" },
  { name: "सरसों (Mustard)", nameEn: "Mustard", price: 4800, change: -1.8, location: "Haryana", trend: "down" },
  { name: "जौ (Barley)", nameEn: "Barley", price: 1650, change: 1.5, location: "Punjab", trend: "up" },
  {
    name: "बाजरा (Pearl Millet)",
    nameEn: "Pearl Millet",
    price: 2200,
    change: 0.8,
    location: "Rajasthan",
    trend: "up",
  },
  { name: "तिल (Sesame)", nameEn: "Sesame", price: 8500, change: 5.2, location: "Gujarat", trend: "up" },
  { name: "हल्दी (Turmeric)", nameEn: "Turmeric", price: 7200, change: -2.1, location: "Tamil Nadu", trend: "down" },
]

// Crop recommendations data
const cropRecommendations = {
  kharif: {
    clay: ["Rice", "Cotton", "Sugarcane", "Maize"],
    sandy: ["Pearl Millet", "Sorghum", "Groundnut", "Cotton"],
    loamy: ["Rice", "Maize", "Cotton", "Sugarcane", "Soybean"],
    black: ["Cotton", "Soybean", "Sorghum", "Sunflower"],
    red: ["Rice", "Ragi", "Groundnut", "Cotton"],
  },
  rabi: {
    clay: ["Wheat", "Barley", "Chickpea", "Mustard"],
    sandy: ["Barley", "Mustard", "Cumin", "Fennel"],
    loamy: ["Wheat", "Barley", "Chickpea", "Pea", "Mustard"],
    black: ["Wheat", "Chickpea", "Safflower", "Linseed"],
    red: ["Wheat", "Barley", "Chickpea", "Mustard"],
  },
  zaid: {
    clay: ["Rice", "Maize", "Fodder crops"],
    sandy: ["Watermelon", "Muskmelon", "Fodder crops"],
    loamy: ["Maize", "Rice", "Vegetables", "Fodder crops"],
    black: ["Cotton", "Sugarcane", "Fodder crops"],
    red: ["Maize", "Vegetables", "Fodder crops"],
  },
}

// Translations data
const translations = {
  en: {
    dashboard: "Dashboard",
    market: "Market",
    advisory: "Advisory",
    pestDetection: "Pest Detection",
    voiceAssistant: "Voice Assistant",
    location: "Location",
    soilType: "Soil Type",
    season: "Season",
    budget: "Budget",
    submit: "Submit",
    search: "Search",
    filter: "Filter",
    loading: "Loading...",
    noResults: "No results found",
  },
  hi: {
    dashboard: "डैशबोर्ड",
    market: "मार्केट",
    advisory: "सलाह",
    pestDetection: "पेस डेटेक्शन",
    voiceAssistant: "वोइस एसिस्टेंट",
    location: "स्थान",
    soilType: "सिल का प्रकार",
    season: "ऋतु",
    budget: "बजट",
    submit: "सबमिट",
    search: "खोजें",
    filter: "फ़िल्टर",
    loading: "लोड हो रहा है...",
    noResults: "कोई परिणाम नहीं मिला",
  },
}

// Initialize app
document.addEventListener("DOMContentLoaded", () => {
  initializeApp()
  setupEventListeners()
  updateLanguage()
  loadMarketPrices()
  loadWeatherForecast()
  startPriceUpdates()
})

function initializeApp() {
  // Set initial language
  document.getElementById("languageSelect").value = currentLanguage

  // Show initial section
  showSection("dashboard")

  // Update navigation
  updateNavigation()
}

function setupEventListeners() {
  // Language switcher
  document.getElementById("languageSelect").addEventListener("change", (e) => {
    currentLanguage = e.target.value
    localStorage.setItem("cropAdvisorLanguage", currentLanguage)
    updateLanguage()
  })

  // Navigation toggle
  document.getElementById("navToggle").addEventListener("click", () => {
    const navMenu = document.getElementById("navMenu")
    navMenu.classList.toggle("active")
  })

  // Navigation links
  document.querySelectorAll(".nav-link").forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault()
      const section = this.getAttribute("href").substring(1)
      showSection(section)
    })
  })

  // Advisory form
  document.getElementById("advisoryForm").addEventListener("submit", (e) => {
    e.preventDefault()
    handleAdvisorySubmission()
  })

  // Pest detection
  document.getElementById("pestImage").addEventListener("change", (e) => {
    if (e.target.files.length > 0) {
      handlePestDetection(e.target.files[0])
    }
  })

  // Voice assistant
  document.getElementById("startListening").addEventListener("click", startVoiceListening)
  document.getElementById("stopListening").addEventListener("click", stopVoiceListening)

  // Market search
  document.getElementById("cropSearch").addEventListener("input", (e) => {
    filterMarketData(e.target.value)
  })

  // Market filter
  document.getElementById("marketFilter").addEventListener("change", (e) => {
    filterMarketByLocation(e.target.value)
  })
}

function updateLanguage() {
  const elements = document.querySelectorAll("[data-translate]")
  elements.forEach((element) => {
    const key = element.getAttribute("data-translate")
    if (translations[currentLanguage] && translations[currentLanguage][key]) {
      element.textContent = translations[currentLanguage][key]
    }
  })

  // Update placeholders
  const placeholderElements = document.querySelectorAll("[data-translate-placeholder]")
  placeholderElements.forEach((element) => {
    const key = element.getAttribute("data-translate-placeholder")
    if (translations[currentLanguage] && translations[currentLanguage][key]) {
      element.placeholder = translations[currentLanguage][key]
    }
  })
}

function showSection(sectionId) {
  // Hide all sections
  document.querySelectorAll(".section").forEach((section) => {
    section.classList.remove("active")
  })

  // Show target section
  document.getElementById(sectionId).classList.add("active")

  // Update navigation
  document.querySelectorAll(".nav-link").forEach((link) => {
    link.classList.remove("active")
    if (link.getAttribute("href") === "#" + sectionId) {
      link.classList.add("active")
    }
  })

  currentSection = sectionId

  // Close mobile menu
  document.getElementById("navMenu").classList.remove("active")
}

function updateNavigation() {
  document.querySelectorAll(".nav-link").forEach((link) => {
    link.classList.remove("active")
    if (link.getAttribute("href") === "#" + currentSection) {
      link.classList.add("active")
    }
  })
}

function loadMarketPrices() {
  const marketGrid = document.getElementById("marketGrid")
  const marketPricesList = document.getElementById("marketPricesList")

  // Load full market grid
  marketGrid.innerHTML = ""
  marketData.forEach((crop) => {
    const card = createMarketCard(crop)
    marketGrid.appendChild(card)
  })

  // Load top prices widget
  marketPricesList.innerHTML = ""
  marketData.slice(0, 5).forEach((crop) => {
    const item = createPriceItem(crop)
    marketPricesList.appendChild(item)
  })
}

function createMarketCard(crop) {
  const card = document.createElement("div")
  card.className = "market-card"

  const trendIcon = crop.trend === "up" ? "fa-arrow-up" : "fa-arrow-down"
  const trendClass = crop.trend === "up" ? "trend-up" : "trend-down"
  const changeSymbol = crop.change > 0 ? "+" : ""

  card.innerHTML = `
        <div class="market-card-header">
            <div class="crop-name">${crop.name}</div>
            <div class="crop-price">₹${crop.price}</div>
        </div>
        <div class="market-location">${crop.location}</div>
        <div class="price-trend ${trendClass}">
            <i class="fas ${trendIcon}"></i>
            <span>${changeSymbol}${crop.change}%</span>
        </div>
    `

  return card
}

function createPriceItem(crop) {
  const item = document.createElement("div")
  item.className = "price-item"

  const changeClass = crop.change > 0 ? "positive" : "negative"
  const changeSymbol = crop.change > 0 ? "+" : ""

  item.innerHTML = `
        <div class="price-name">${crop.name}</div>
        <div>
            <div class="price-value">₹${crop.price}</div>
            <div class="price-change ${changeClass}">${changeSymbol}${crop.change}%</div>
        </div>
    `

  return item
}

function startPriceUpdates() {
  setInterval(() => {
    // Simulate price updates
    marketData.forEach((crop) => {
      const change = (Math.random() - 0.5) * 10 // Random change between -5% and +5%
      crop.change = Number.parseFloat(change.toFixed(1))
      crop.trend = change > 0 ? "up" : "down"
      crop.price = Math.max(100, crop.price + Math.round((crop.price * change) / 100))
    })

    loadMarketPrices()
  }, 30000) // Update every 30 seconds
}

function filterMarketData(searchTerm) {
  const filteredData = marketData.filter(
    (crop) =>
      crop.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      crop.nameEn.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const marketGrid = document.getElementById("marketGrid")
  marketGrid.innerHTML = ""
  filteredData.forEach((crop) => {
    const card = createMarketCard(crop)
    marketGrid.appendChild(card)
  })
}

function filterMarketByLocation(location) {
  const filteredData =
    location === "all"
      ? marketData
      : marketData.filter((crop) => crop.location.toLowerCase().includes(location.toLowerCase()))

  const marketGrid = document.getElementById("marketGrid")
  marketGrid.innerHTML = ""
  filteredData.forEach((crop) => {
    const card = createMarketCard(crop)
    marketGrid.appendChild(card)
  })
}

function handleAdvisorySubmission() {
  const location = document.getElementById("location").value
  const soilType = document.getElementById("soilType").value
  const season = document.getElementById("season").value
  const budget = document.getElementById("budget").value

  if (!location || !soilType || !season || !budget) {
    alert(translations[currentLanguage].noResults)
    return
  }

  showLoading()

  setTimeout(() => {
    const recommendations = cropRecommendations[season][soilType] || []
    displayAdvisoryResults(recommendations, { location, soilType, season, budget })
    hideLoading()
  }, 2000)
}

function displayAdvisoryResults(crops, formData) {
  const resultsDiv = document.getElementById("advisoryResults")

  let resultsHTML = `
        <h3>${translations[currentLanguage].recommendedCrops} for ${formData.location}</h3>
        <div class="recommendations-grid">
    `

  crops.forEach((crop, index) => {
    const suitability = 85 + Math.random() * 10 // Random suitability between 85-95%
    const cropYield = Math.round(20 + Math.random() * 30) // Random yield between 20-50 quintals/acre

    resultsHTML += `
            <div class="recommendation-card">
                <div class="recommendation-header">
                    <h4>${crop}</h4>
                    <div class="suitability-score">${suitability.toFixed(1)}%</div>
                </div>
                <div class="recommendation-details">
                    <p><strong>${translations[currentLanguage].expectedYield}:</strong> ${cropYield} quintals/acre</p>
                    <p><strong>${translations[currentLanguage].bestPlantingTime}:</strong> ${getPlantingTime(formData.season)}</p>
                    <p><strong>${translations[currentLanguage].marketPrice}:</strong> ₹${getMarketPrice(crop)}/quintal</p>
                </div>
                <div class="recommendation-tips">
                    <h5>${translations[currentLanguage].keyTips}:</h5>
                    <ul>
                        ${getCropTips(crop)
                          .map((tip) => `<li>${tip}</li>`)
                          .join("")}
                    </ul>
                </div>
            </div>
        `
  })

  resultsHTML += "</div>"

  resultsDiv.innerHTML = resultsHTML
  resultsDiv.classList.remove("hidden")
}

function getPlantingTime(season) {
  const times = {
    kharif: "June-July",
    rabi: "October-December",
    zaid: "March-April",
  }
  return times[season] || translations[currentLanguage].consultLocalExpert
}

function getMarketPrice(crop) {
  const prices = {
    Rice: 3200,
    Wheat: 2150,
    Cotton: 5800,
    Maize: 1850,
    Soybean: 4200,
    Chickpea: 5500,
    Mustard: 4800,
    Barley: 1650,
    "Pearl Millet": 2200,
    Sorghum: 2000,
    Groundnut: 5200,
    Sunflower: 4500,
  }
  return prices[crop] || 2500
}

function getCropTips(crop) {
  const tips = {
    Rice: ["Maintain water level 2-3 inches", "Use certified seeds", "Apply organic manure"],
    Wheat: ["Sow at proper depth", "Ensure good drainage", "Monitor for rust disease"],
    Cotton: ["Use drip irrigation", "Regular pest monitoring", "Proper spacing between plants"],
    Maize: ["Plant in rows", "Adequate fertilization", "Weed control important"],
    Soybean: ["Inoculate seeds", "Avoid waterlogging", "Harvest at right maturity"],
    Chickpea: ["Avoid excess moisture", "Use disease-free seeds", "Proper land preparation"],
    Mustard: ["Timely sowing important", "Light irrigation needed", "Protect from aphids"],
    Barley: ["Choose suitable variety", "Balanced fertilization", "Timely harvesting"],
  }
  return (
    tips[crop] || ["Follow local agricultural practices", "Consult agricultural experts", "Monitor weather conditions"]
  )
}

function handlePestDetection(file) {
  showLoading()

  // Simulate AI processing
  setTimeout(() => {
    const pestResults = {
      pest: "Aphids",
      confidence: 92.5,
      severity: "Medium",
      treatment: [
        "Spray neem oil solution (5ml per liter water)",
        "Use yellow sticky traps",
        "Apply insecticidal soap",
        "Encourage beneficial insects like ladybugs",
      ],
      prevention: [
        "Regular monitoring of crops",
        "Maintain proper plant spacing",
        "Remove infected plant parts",
        "Use resistant varieties when available",
      ],
    }

    displayPestResults(pestResults)
    hideLoading()
  }, 3000)
}

function displayPestResults(results) {
  const resultsDiv = document.getElementById("pestResults")

  const severityColor = {
    Low: "#10b981",
    Medium: "#f59e0b",
    High: "#ef4444",
  }[results.severity]

  resultsDiv.innerHTML = `
        <div class="pest-result-card">
            <div class="pest-header">
                <h3>${translations[currentLanguage].detectionResults}</h3>
                <div class="confidence-score">${translations[currentLanguage].confidence}: ${results.confidence}%</div>
            </div>
            
            <div class="pest-identification">
                <h4>${translations[currentLanguage].identifiedPest}: ${results.pest}</h4>
                <div class="severity-badge" style="background: ${severityColor}; color: white; padding: 0.25rem 0.5rem; border-radius: 0.25rem; display: inline-block;">
                    ${translations[currentLanguage].severity}: ${results.severity}
                </div>
            </div>
            
            <div class="treatment-section">
                <h4>${translations[currentLanguage].recommendedTreatment}:</h4>
                <ul>
                    ${results.treatment.map((treatment) => `<li>${treatment}</li>`).join("")}
                </ul>
            </div>
            
            <div class="prevention-section">
                <h4>${translations[currentLanguage].preventionMeasures}:</h4>
                <ul>
                    ${results.prevention.map((prevention) => `<li>${prevention}</li>`).join("")}
                </ul>
            </div>
        </div>
    `

  resultsDiv.classList.remove("hidden")
}

function startVoiceListening() {
  if (!("webkitSpeechRecognition" in window) && !("SpeechRecognition" in window)) {
    alert(translations[currentLanguage].voiceNotSupported)
    return
  }

  const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)()
  recognition.lang = getVoiceLanguage(currentLanguage)
  recognition.continuous = false
  recognition.interimResults = false

  document.getElementById("startListening").classList.add("hidden")
  document.getElementById("stopListening").classList.remove("hidden")

  const transcriptDiv = document.getElementById("voiceTranscript")
  transcriptDiv.classList.remove("hidden")
  transcriptDiv.innerHTML = "<p>" + translations[currentLanguage].listening + "...</p>"

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript
    transcriptDiv.innerHTML = `<p><strong>${translations[currentLanguage].youSaid}:</strong> ${transcript}</p>`

    // Simulate AI response
    setTimeout(() => {
      const response = generateVoiceResponse(transcript)
      displayVoiceResponse(response)
    }, 1000)
  }

  recognition.onerror = (event) => {
    transcriptDiv.innerHTML = `<p>${translations[currentLanguage].error}: ${event.error}</p>`
    stopVoiceListening()
  }

  recognition.onend = () => {
    stopVoiceListening()
  }

  recognition.start()
  isListening = true
}

function stopVoiceListening() {
  document.getElementById("startListening").classList.remove("hidden")
  document.getElementById("stopListening").classList.add("hidden")
  isListening = false
}

function getVoiceLanguage(lang) {
  const voiceLangs = {
    en: "en-US",
    hi: "hi-IN",
    bn: "bn-IN",
    te: "te-IN",
    ta: "ta-IN",
    gu: "gu-IN",
    mr: "mr-IN",
    pa: "pa-IN",
  }
  return voiceLangs[lang] || "en-US"
}

function generateVoiceResponse(query) {
  const responses = [
    "Based on your location and soil type, I recommend planting wheat this season. The current market price is ₹2150 per quintal.",
    "For pest control, try using neem oil spray. It's organic and effective against most common pests.",
    "The weather forecast shows good rainfall this week. It's a perfect time for sowing kharif crops.",
    "Cotton prices have increased by 4.1% this week. Consider selling if you have stored cotton.",
    "For better yield, ensure proper spacing between plants and use certified seeds.",
  ]

  return responses[Math.floor(Math.random() * responses.length)]
}

function displayVoiceResponse(response) {
  const responseDiv = document.getElementById("voiceResponse")
  responseDiv.innerHTML = `<p><strong>CropAdvisor:</strong> ${response}</p>`
  responseDiv.classList.remove("hidden")

  // Text-to-speech
  if ("speechSynthesis" in window) {
    const utterance = new SpeechSynthesisUtterance(response)
    utterance.lang = getVoiceLanguage(currentLanguage)
    speechSynthesis.speak(utterance)
  }
}

function showLoading() {
  document.getElementById("loadingOverlay").classList.remove("hidden")
}

function hideLoading() {
  document.getElementById("loadingOverlay").classList.add("hidden")
}

// Weather forecast data
function loadWeatherForecast() {
  const forecastGrid = document.getElementById("forecastGrid")
  const forecast = [
    { day: "Today", temp: "28°C", icon: "fa-sun", desc: "Sunny" },
    { day: "Tomorrow", temp: "26°C", icon: "fa-cloud-rain", desc: "Rainy" },
    { day: "Wed", temp: "24°C", icon: "fa-cloud", desc: "Cloudy" },
    { day: "Thu", temp: "27°C", icon: "fa-cloud-sun", desc: "Partly Cloudy" },
    { day: "Fri", temp: "29°C", icon: "fa-sun", desc: "Sunny" },
  ]

  forecastGrid.innerHTML = ""
  forecast.forEach((day) => {
    const card = document.createElement("div")
    card.className = "forecast-card"
    card.innerHTML = `
            <div class="forecast-day">${day.day}</div>
            <i class="fas ${day.icon} forecast-icon"></i>
            <div class="forecast-temp">${day.temp}</div>
            <div class="forecast-desc">${day.desc}</div>
        `
    forecastGrid.appendChild(card)
  })
}
