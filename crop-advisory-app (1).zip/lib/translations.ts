export const translations = {
  en: {
    // Header
    appName: "CropAdvisor",
    tagline: "Smart Farming Assistant",
    country: "India",
    voice: "Voice",
    analytics: "Analytics",

    // Welcome Section
    welcome: "Welcome Farmer! 🌾",
    welcomeDesc: "Your personal crop advisory dashboard is ready with today's insights.",

    // Kisan Call Center
    kisanCallCenter: "Kisan Call Center",
    freeSupport: "24x7 Free Support",
    callNow: "Call Now",
    immediateHelp: "For immediate assistance",

    // Quick Stats
    soilHealth: "Soil Health",
    soilGood: "Good",
    weather: "Weather",
    sunny: "Sunny",
    pestRisk: "Pest Risk",
    low: "Low",
    market: "Market",
    rising: "Rising",

    // Main Features
    cropAdvisory: "Crop Advisory",
    aiRecommendations: "AI-powered recommendations",
    cropAdvisoryDesc: "Get personalized crop recommendations based on your soil, weather, and location.",
    getRecommendations: "Get Recommendations",

    weatherInfo: "Weather Information",
    realtimeAlerts: "Real-time weather alerts",
    weatherDesc: "Stay ahead with weather-based alerts and predictions for your crops.",
    viewWeather: "View Weather",

    pestDetection: "Pest Detection",
    aiImageAnalysis: "AI image analysis",
    pestDetectionDesc: "Upload crop images to detect pests and diseases with AI-powered analysis.",
    scanCrop: "Scan Crop",

    marketPrices: "Market Prices",
    livePriceTracking: "Live price tracking",
    marketPricesDesc: "Track real-time market prices and get the best selling opportunities.",
    viewPrices: "View Prices",

    // Loan Services
    loanServices: "Loan Services",
    quickLoanApproval: "Quick loan approval",
    loanServicesDesc: "Access various loan schemes from different banks for agricultural needs.",
    applyForLoan: "Apply for Loan",
    quickLoans: "Quick Loans",
    instantApproval: "Instant approval available",
    apply: "Apply",
    viewAllLoans: "View All Loans",

    // Government Schemes
    governmentSchemes: "Government Schemes",
    schemesForFarmers: "Schemes for farmers",
    governmentSchemesDesc: "Explore various government schemes and subsidies available for farmers.",
    viewSchemes: "View Schemes",

    pmKisan: "PM-KISAN",
    pmKisanDesc: "₹6,000 per year direct benefit transfer to farmer families",
    pmKisanAmount: "₹6,000/year",
    pmKisanInstallments: "3 installments of ₹2,000 each",

    pmFasal: "PM Fasal Bima Yojana",
    pmFasalDesc: "Crop insurance scheme providing financial support for crop loss",
    pmFasalCoverage: "Comprehensive crop insurance",
    pmFasalRisks: "Covers natural calamities & pest attacks",

    soilHealthCard: "Soil Health Card",
    soilHealthCardDesc: "Free soil testing and nutrient management recommendations",
    soilHealthCardBenefit: "Free soil testing",
    soilHealthCardRecommendations: "Customized fertilizer recommendations",

    organicFarming: "Paramparagat Krishi Vikas Yojana",
    organicFarmingDesc: "Promotes organic farming practices with financial assistance",
    organicFarmingSupport: "₹50,000/hectare support",
    organicFarmingCertification: "Organic certification assistance",

    // Loans & Credit
    loansCredit: "Loans & Credit",
    bankingServices: "Banking services for farmers",
    loansCreditDesc: "Access various loan schemes from different banks for agricultural needs.",
    applyLoan: "Apply for Loan",

    kisanCreditCard: "Kisan Credit Card",
    kisanCreditCardDesc: "Revolving credit facility for agricultural needs",
    kisanCreditCardRate: "Interest from 7% p.a.",
    kisanCreditCardLimit: "Up to ₹3 lakhs",

    cropLoan: "Crop Loan",
    cropLoanDesc: "Short-term loans for crop production expenses",
    cropLoanPurpose: "Seeds, fertilizers, pesticides",
    cropLoanTenure: "Up to 12 months",

    farmMechanization: "Farm Mechanization Loan",
    farmMechanizationDesc: "Loans for purchasing agricultural equipment",
    farmMechanizationEquipment: "Tractors, harvesters, tillers",
    farmMechanizationTenure: "Up to 7 years",

    goldLoan: "Gold Loan for Agriculture",
    goldLoanDesc: "Quick loans against gold jewelry for farming needs",
    goldLoanRate: "Competitive interest rates",
    goldLoanProcessing: "Quick processing",

    // Document Upload
    uploadDocuments: "Upload Documents",
    documentsRequired: "Required Documents",
    aadharCard: "Aadhar Card",
    panCard: "PAN Card",
    landRecords: "Land Records",
    bankStatement: "Bank Statement",
    incomeProof: "Income Proof",
    cropDetails: "Crop Details",
    uploadFile: "Upload File",
    fileUploaded: "File Uploaded Successfully",
    submitApplication: "Submit Application",
    applicationSubmitted: "Application Submitted Successfully",
  },

  hi: {
    // Header
    appName: "CropAdvisor",
    tagline: "स्मार्ट खेती सहायक",
    country: "भारत",
    voice: "आवाज़",
    analytics: "विश्लेषण",

    // Welcome Section
    welcome: "नमस्कार किसान भाई! 🌾",
    welcomeDesc: "आपका व्यक्तिगत फसल सलाहकार डैशबोर्ड आज की अंतर्दृष्टि के साथ तैयार है।",

    // Kisan Call Center
    kisanCallCenter: "किसान कॉल सेंटर",
    freeSupport: "24x7 निःशुल्क सहायता",
    callNow: "अभी कॉल करें",
    immediateHelp: "तत्काल सहायता के लिए",

    // Quick Stats
    soilHealth: "मिट्टी स्वास्थ्य",
    soilGood: "अच्छा",
    weather: "मौसम",
    sunny: "धूप",
    pestRisk: "कीट जोखिम",
    low: "कम",
    market: "बाज़ार",
    rising: "बढ़ रहा",

    // Main Features
    cropAdvisory: "फसल सलाह",
    aiRecommendations: "AI-संचालित सिफारिशें",
    cropAdvisoryDesc: "अपनी मिट्टी, मौसम और स्थान के आधार पर व्यक्तिगत फसल सिफारिशें प्राप्त करें।",
    getRecommendations: "सिफारिशें प्राप्त करें",

    weatherInfo: "मौसम जानकारी",
    realtimeAlerts: "वास्तविक समय मौसम अलर्ट",
    weatherDesc: "अपनी फसलों के लिए मौसम-आधारित अलर्ट और भविष्यवाणी के साथ आगे रहें।",
    viewWeather: "मौसम देखें",

    pestDetection: "कीट पहचान",
    aiImageAnalysis: "AI छवि विश्लेषण",
    pestDetectionDesc: "AI-संचालित विश्लेषण के साथ कीटों और बीमारियों का पता लगाने के लिए फसल की छवियां अपलोड करें।",
    scanCrop: "फसल स्कैन करें",

    marketPrices: "बाज़ार भाव",
    livePriceTracking: "लाइव मूल्य ट्रैकिंग",
    marketPricesDesc: "वास्तविक समय बाज़ार मूल्यों को ट्रैक करें और सर्वोत्तम बिक्री अवसर प्राप्त करें।",
    viewPrices: "मूल्य देखें",

    // Loan Services
    loanServices: "ऋण सेवाएं",
    quickLoanApproval: "त्वरित ऋण अनुमोदन",
    loanServicesDesc: "कृषि आवश्यकताओं के लिए विभिन्न बैंकों से विभिन्न ऋण योजनाओं तक पहुंच।",
    applyForLoan: "ऋण के लिए आवेदन करें",
    quickLoans: "त्वरित ऋण",
    instantApproval: "तत्काल अनुमोदन उपलब्ध",
    apply: "आवेदन करें",
    viewAllLoans: "सभी ऋण देखें",

    // Government Schemes
    governmentSchemes: "सरकारी योजनाएं",
    schemesForFarmers: "किसानों के लिए योजनाएं",
    governmentSchemesDesc: "किसानों के लिए उपलब्ध विभिन्न सरकारी योजनाओं और सब्सिडी का अन्वेषण करें।",
    viewSchemes: "योजनाएं देखें",

    pmKisan: "पीएम-किसान",
    pmKisanDesc: "किसान परिवारों को ₹6,000 प्रति वर्ष प्रत्यक्ष लाभ हस्तांतरण",
    pmKisanAmount: "₹6,000/वर्ष",
    pmKisanInstallments: "₹2,000 की 3 किस्तें",

    pmFasal: "पीएम फसल बीमा योजना",
    pmFasalDesc: "फसल नुकसान के लिए वित्तीय सहायता प्रदान करने वाली फसल बीमा योजना",
    pmFasalCoverage: "व्यापक फसल बीमा",
    pmFasalRisks: "प्राकृतिक आपदाओं और कीट हमलों को कवर करता है",

    soilHealthCard: "मृदा स्वास्थ्य कार्ड",
    soilHealthCardDesc: "मुफ्त मिट्टी परीक्षण और पोषक तत्व प्रबंधन सिफारिशें",
    soilHealthCardBenefit: "मुफ्त मिट्टी परीक्षण",
    soilHealthCardRecommendations: "अनुकूलित उर्वरक सिफारिशें",

    organicFarming: "परंपरागत कृषि विकास योजना",
    organicFarmingDesc: "वित्तीय सहायता के साथ जैविक खेती प्रथाओं को बढ़ावा देता है",
    organicFarmingSupport: "₹50,000/हेक्टेयर सहायता",
    organicFarmingCertification: "जैविक प्रमाणन सहायता",

    // Loans & Credit
    loansCredit: "ऋण और क्रेडिट",
    bankingServices: "किसानों के लिए बैंकिंग सेवाएं",
    loansCreditDesc: "कृषि आवश्यकताओं के लिए विभिन्न बैंकों से विभिन्न ऋण योजनाओं तक पहुंच।",
    applyLoan: "ऋण के लिए आवेदन करें",

    kisanCreditCard: "किसान क्रेडिट कार्ड",
    kisanCreditCardDesc: "कृषि आवश्यकताओं के लिए रिवॉल्विंग क्रेडिट सुविधा",
    kisanCreditCardRate: "7% प्रति वर्ष से ब्याज",
    kisanCreditCardLimit: "₹3 लाख तक",

    cropLoan: "फसल ऋण",
    cropLoanDesc: "फसल उत्पादन खर्च के लिए अल्पकालिक ऋण",
    cropLoanPurpose: "बीज, उर्वरक, कीटनाशक",
    cropLoanTenure: "12 महीने तक",

    farmMechanization: "कृषि यंत्रीकरण ऋण",
    farmMechanizationDesc: "कृषि उपकरण खरीदने के लिए ऋण",
    farmMechanizationEquipment: "ट्रैक्टर, हार्वेस्टर, टिलर",
    farmMechanizationTenure: "7 साल तक",

    goldLoan: "कृषि के लिए गोल्ड लोन",
    goldLoanDesc: "खेती की जरूरतों के लिए सोने के गहनों के बदले त्वरित ऋण",
    goldLoanRate: "प्रतिस्पर्धी ब्याज दरें",
    goldLoanProcessing: "त्वरित प्रसंस्करण",

    // Document Upload
    uploadDocuments: "दस्तावेज़ अपलोड करें",
    documentsRequired: "आवश्यक दस्तावेज़",
    aadharCard: "आधार कार्ड",
    panCard: "पैन कार्ड",
    landRecords: "भूमि रिकॉर्ड",
    bankStatement: "बैंक स्टेटमेंट",
    incomeProof: "आय प्रमाण",
    cropDetails: "फसल विवरण",
    uploadFile: "फ़ाइल अपलोड करें",
    fileUploaded: "फ़ाइल सफलतापूर्वक अपलोड की गई",
    submitApplication: "आवेदन जमा करें",
    applicationSubmitted: "आवेदन सफलतापूर्वक जमा किया गया",
  },

  bn: {
    // Header
    appName: "CropAdvisor",
    tagline: "স্মার্ট কৃষি সহায়ক",
    country: "ভারত",
    voice: "কণ্ঠস্বর",
    analytics: "বিশ্লেষণ",

    // Welcome Section
    welcome: "স্বাগতম কৃষক ভাই! 🌾",
    welcomeDesc: "আপনার ব্যক্তিগত ফসল পরামর্শ ড্যাশবোর্ড আজকের অন্তর্দৃষ্টি নিয়ে প্রস্তুত।",

    // Kisan Call Center
    kisanCallCenter: "কিষাণ কল সেন্টার",
    freeSupport: "২৪x৭ বিনামূল্যে সহায়তা",
    callNow: "এখনই কল করুন",
    immediateHelp: "তাৎক্ষণিক সহায়তার জন্য",

    // Quick Stats
    soilHealth: "মাটির স্বাস্থ্য",
    soilGood: "ভাল",
    weather: "আবহাওয়া",
    sunny: "রৌদ্রোজ্জ্বল",
    pestRisk: "কীটপতঙ্গের ঝুঁকি",
    low: "কম",
    market: "বাজার",
    rising: "বৃদ্ধি পাচ্ছে",

    // Main Features
    cropAdvisory: "ফসল পরামর্শ",
    aiRecommendations: "AI-চালিত সুপারিশ",
    cropAdvisoryDesc: "আপনার মাটি, আবহাওয়া এবং অবস্থানের ভিত্তিতে ব্যক্তিগত ফসল সুপারিশ পান।",
    getRecommendations: "সুপারিশ পান",

    weatherInfo: "আবহাওয়া তথ্য",
    realtimeAlerts: "রিয়েল-টাইম আবহাওয়া সতর্কতা",
    weatherDesc: "আপনার ফসলের জন্য আবহাওয়া-ভিত্তিক সতর্কতা এবং পূর্বাভাস নিয়ে এগিয়ে থাকুন।",
    viewWeather: "আবহাওয়া দেখুন",

    pestDetection: "কীটপতঙ্গ সনাক্তকরণ",
    aiImageAnalysis: "AI ছবি বিশ্লেষণ",
    pestDetectionDesc: "AI-চালিত বিশ্লেষণের সাথে কীটপতঙ্গ এবং রোগ সনাক্ত করতে ফসলের ছবি আপলোড করুন।",
    scanCrop: "ফসল স্ক্যান করুন",

    marketPrices: "বাজার দাম",
    livePriceTracking: "লাইভ দাম ট্র্যাকিং",
    marketPricesDesc: "রিয়েল-টাইম বাজার দাম ট্র্যাক করুন এবং সেরা বিক্রয় সুযোগ পান।",
    viewPrices: "দাম দেখুন",

    // Loan Services
    loanServices: "ঋণ সেবাসমূহ",
    quickLoanApproval: "দ্রুত ঋণ অনুমোদন",
    loanServicesDesc: "কৃষি প্রয়োজনের জন্য বিভিন্ন ব্যাংক থেকে বিভিন্ন ঋণ প্রকল্প অ্যাক্সেস করুন।",
    applyForLoan: "ঋণের জন্য আবেদন করুন",
    quickLoans: "দ্রুত ঋণ",
    instantApproval: "তাৎক্ষণিক অনুমোদন উপলব্ধ",
    apply: "আবেদন করুন",
    viewAllLoans: "সব ঋণ দেখুন",
  },

  te: {
    // Header
    appName: "CropAdvisor",
    tagline: "స్మార్ట్ వ్యవసాయ సహాయకుడు",
    country: "భారతదేశం",
    voice: "వాయిస్",
    analytics: "విశ్లేషణలు",

    // Welcome Section
    welcome: "స్వాగతం రైతు అన్నా! 🌾",
    welcomeDesc: "మీ వ్యక్తిగత పంట సలహా డ్యాష్‌బోర్డ్ నేటి అంతర్దృష్టులతో సిద్ధంగా ఉంది.",

    // Kisan Call Center
    kisanCallCenter: "కిసాన్ కాల్ సెంటర్",
    freeSupport: "24x7 ఉచిత మద్దతు",
    callNow: "ఇప్పుడే కాల్ చేయండి",
    immediateHelp: "తక్షణ సహాయం కోసం",

    // Quick Stats
    soilHealth: "మట్టి ఆరోగ్యం",
    soilGood: "మంచిది",
    weather: "వాతావరణం",
    sunny: "ఎండ",
    pestRisk: "కీటకాల ప్రమాదం",
    low: "తక్కువ",
    market: "మార్కెట్",
    rising: "పెరుగుతోంది",

    // Main Features
    cropAdvisory: "పంట సలహా",
    aiRecommendations: "AI-ఆధారిత సిఫార్సులు",
    cropAdvisoryDesc: "మీ మట్టి, వాతావరణం మరియు స్థానం ఆధారంగా వ్యక్తిగత పంట సిఫార్సులను పొందండి.",
    getRecommendations: "సిఫార్సులు పొందండి",

    weatherInfo: "వాతావరణ సమాచారం",
    realtimeAlerts: "రియల్-టైమ్ వాతావరణ హెచ్చరికలు",
    weatherDesc: "మీ పంటల కోసం వాతావరణ-ఆధారిత హెచ్చరికలు మరియు అంచనాలతో ముందుగా ఉండండి.",
    viewWeather: "వాతావరణం చూడండి",

    pestDetection: "కీటకాల గుర్తింపు",
    aiImageAnalysis: "AI చిత్ర విశ్లేషణ",
    pestDetectionDesc: "AI-ఆధారిత విశ్లేషణతో కీటకాలు మరియు వ్యాధులను గుర్తింపు చేయడానికి పంట చిత్రాలను అప్‌లోడ్ చేయండి.",
    scanCrop: "పంట స్కాన్ చేయండి",

    marketPrices: "మార్కెట్ ధరలు",
    livePriceTracking: "లైవ్ ధర ట్రాకింగ్",
    marketPricesDesc: "రియల్-టైమ్ మార్కెట్ ధరలను ట్రాక్ చేయండి మరియు ఉత్తమ అమ్మకపు అవకాశాలను పొందండి.",
    viewPrices: "ధరలు చూడండి",

    // Loan Services
    loanServices: "రుణ సేవలు",
    quickLoanApproval: "త్వరిత రుణ అనుమతి",
    loanServicesDesc: "వ్యవసాయ అవసరాల కోసం వివిధ బ్యాంకుల నుండి వివిధ రుణ పథకాలను యాక్సెస్ చేయండి.",
    applyForLoan: "రుణం కోసం దరఖాస్తు చేయండి",
    quickLoans: "త్వరిత రుణాలు",
    instantApproval: "తక్షణ అనుమతి అందుబాటులో",
    apply: "దరఖాస్తు చేయండి",
    viewAllLoans: "అన్ని రుణాలను చూడండి",
  },

  ta: {
    // Header
    appName: "CropAdvisor",
    tagline: "ஸ்மார்ட் விவசாய உதவியாளர்",
    country: "இந்தியா",
    voice: "குரல்",
    analytics: "பகுப்பாய்வு",

    // Welcome Section
    welcome: "வணக்கம் விவசாயி அண்ணா! 🌾",
    welcomeDesc: "உங்கள் தனிப்பட்ட பயிர் ஆலோசனை டாஷ்போர்டு இன்றைய நுண்ணறிவுகளுடன் தயாராக உள்ளது.",

    // Kisan Call Center
    kisanCallCenter: "கிசான் கால் சென்டர்",
    freeSupport: "24x7 இலவச ஆதரவு",
    callNow: "இப்போதே அழைக்கவும்",
    immediateHelp: "உடனடி உதவிக்கு",

    // Quick Stats
    soilHealth: "மண் ஆரோக்கியம்",
    soilGood: "நல்லது",
    weather: "வானிலை",
    sunny: "வெயில்",
    pestRisk: "பூச்சி ஆபத்து",
    low: "குறைவு",
    market: "சந்தை",
    rising: "உயர்ந்து வருகிறது",

    // Main Features
    cropAdvisory: "பயிர் ஆலோசனை",
    aiRecommendations: "AI-இயங்கும் பரிந்துரைகள்",
    cropAdvisoryDesc: "உங்கள் மண், வானிலை மற்றும் இடத்தின் அடிப்படையில் தனிப்பட்ட பயிர் பரிந்துரைகளைப் பெறுங்கள்.",
    getRecommendations: "பரிந்துரைகளைப் பெறுங்கள்",

    weatherInfo: "வானிலை தகவல்",
    realtimeAlerts: "நிகழ்நேர வானிலை எச்சரிக்கைகள்",
    weatherDesc: "உங்கள் பயிர்களுக்கான வானிலை அடிப்படையிலான எச்சரிக்கைகள் மற்றும் கணிப்புகளுடன் முன்னேறுங்கள்.",
    viewWeather: "வானிலையைப் பார்க்கவும்",

    pestDetection: "பூச்சி கண்டறிதல்",
    aiImageAnalysis: "AI படம் பகுப்பாய்வு",
    pestDetectionDesc: "AI-இயங்கும் பகுப்பாய்வுடன் பூச்சிகள் மற்றும் நோய்களைக் கண்டறிய பயிர் படங்களைப் பதிவேற்றவும்.",
    scanCrop: "பயிரை ஸ்கேன் செய்யவும்",

    marketPrices: "சந்தை விலைகள்",
    livePriceTracking: "நேரடி விலை கண்காணிப்பு",
    marketPricesDesc: "நிகழ்நேர சந்தை விலைகளைக் கண்காணித்து சிறந்த விற்பனை வாய்ப்புகளைப் பெறுங்கள்.",
    viewPrices: "விலைகளைப் பார்க்கவும்",

    // Loan Services
    loanServices: "கடன் சேவைகள்",
    quickLoanApproval: "விரைவு கடன் அனுமதி",
    loanServicesDesc: "விவசாய தேவைகளுக்காக பல்வேறு வங்கிகளிலிருந்து பல்வேறு கடன் திட்டங்களை அணுகவும்.",
    applyForLoan: "கடனுக்கு விண்ணப்பிக்கவும்",
    quickLoans: "விரைவு கடன்கள்",
    instantApproval: "உடனடி அனுமதி கிடைக்கும்",
    apply: "விண்ணப்பிக்கவும்",
    viewAllLoans: "அனைத்து கடன்களையும் பார்க்கவும்",
  },

  gu: {
    // Header
    appName: "CropAdvisor",
    tagline: "સ્માર્ટ ખેતી સહાયક",
    country: "ભારત",
    voice: "અવાજ",
    analytics: "વિશ્લેષણ",

    // Welcome Section
    welcome: "સ્વાગત છે ખેડૂત ભાઈ! 🌾",
    welcomeDesc: "તમારું વ્યક્તિગત પાક સલાહકાર ડેશબોર્ડ આજની અંતર્દૃષ્ટિ સાથે તૈયાર છે.",

    // Kisan Call Center
    kisanCallCenter: "કિસાન કોલ સેન્ટર",
    freeSupport: "24x7 મફત સહાય",
    callNow: "હવે કોલ કરો",
    immediateHelp: "તાત્કાલિક સહાય માટે",

    // Quick Stats
    soilHealth: "માટીની તંદુરસ્તી",
    soilGood: "સારી",
    weather: "હવામાન",
    sunny: "સૂર્યપ્રકાશ",
    pestRisk: "જંતુ જોખમ",
    low: "ઓછું",
    market: "બજાર",
    rising: "વધી રહ્યું છે",

    // Main Features
    cropAdvisory: "પાક સલાહ",
    aiRecommendations: "AI-સંચાલિત ભલામણો",
    cropAdvisoryDesc: "તમારી માટી, હવામાન અને સ્થાનના આધારે વ્યક્તિગત પાક ભલામણો મેળવો.",
    getRecommendations: "ભલામણો મેળવો",

    weatherInfo: "હવામાન માહિતી",
    realtimeAlerts: "રીઅલ-ટાઇમ હવામાન ચેતવણીઓ",
    weatherDesc: "તમારા પાકો માટે હવામાન-આધારિત ચેતવણીઓ અને આગાહીઓ સાથે આગળ રહો.",
    viewWeather: "હવામાન જુઓ",

    pestDetection: "જંતુ ઓળખ",
    aiImageAnalysis: "AI છબી વિશ્લેષણ",
    pestDetectionDesc: "AI-સંચાલિત વિશ્લેષણ સાથે જંતુઓ અને રોગોને શોધવા માટે પાકની છબીઓ અપલોડ કરો.",
    scanCrop: "પાક સ્કેન કરો",

    marketPrices: "બજાર ભાવ",
    livePriceTracking: "લાઇવ ભાવ ટ્રેકિંગ",
    marketPricesDesc: "રીઅલ-ટાઇમ બજાર ભાવોને ટ્રેક કરો અને શ્રેષ્ઠ વેચાણ તકો મેળવો.",
    viewPrices: "ભાવ જુઓ",

    // Loan Services
    loanServices: "લોન સેવાઓ",
    quickLoanApproval: "ઝડપી લોન મંજૂરી",
    loanServicesDesc: "કૃષિ જરૂરિયાતો માટે વિવિધ બેંકોમાંથી વિવિધ લોન યોજનાઓ મેળવો.",
    applyForLoan: "લોન માટે અરજી કરો",
    quickLoans: "ઝડપી લોન",
    instantApproval: "તાત્કાલિક મંજૂરી ઉપલબ્ધ",
    apply: "અરજી કરો",
    viewAllLoans: "બધી લોન જુઓ",
  },

  mr: {
    // Header
    appName: "CropAdvisor",
    tagline: "स्मार्ट शेती सहाय्यक",
    country: "भारत",
    voice: "आवाज",
    analytics: "विश्लेषण",

    // Welcome Section
    welcome: "स्वागत शेतकरी भाऊ! 🌾",
    welcomeDesc: "तुमचा वैयक्तिक पीक सल्लागार डॅशबोर्ड आजच्या अंतर्दृष्टीसह तयार आहे.",

    // Kisan Call Center
    kisanCallCenter: "किसान कॉल सेंटर",
    freeSupport: "24x7 मोफत मदत",
    callNow: "आता कॉल करा",
    immediateHelp: "तत्काळ मदतीसाठी",

    // Quick Stats
    soilHealth: "माती आरोग्य",
    soilGood: "चांगली",
    weather: "हवामान",
    sunny: "सूर्यप्रकाश",
    pestRisk: "कीड धोका",
    low: "कमी",
    market: "बाजार",
    rising: "वाढत आहे",

    // Main Features
    cropAdvisory: "पीक सल्ला",
    aiRecommendations: "AI-चालित शिफारसी",
    cropAdvisoryDesc: "तुमची माती, हवामान आणि स्थानावर आधारित वैयक्तिक पीक शिफारसी मिळवा.",
    getRecommendations: "शिफारसी मिळवा",

    weatherInfo: "हवामान माहिती",
    realtimeAlerts: "रिअल-टाइम हवामान इशारे",
    weatherDesc: "तुमच्या पिकांसाठी हवामान-आधारित इशारे आणि अंदाजांसह पुढे रहा.",
    viewWeather: "हवामान पहा",

    pestDetection: "कीड ओळख",
    aiImageAnalysis: "AI प्रतिमा विश्लेषण",
    pestDetectionDesc: "AI-चालित विश्लेषणासह कीड आणि रोग शोधण्यासाठी पिकाच्या प्रतिमा अपलोड करा.",
    scanCrop: "पीक स्कॅन करा",

    marketPrices: "बाजार भाव",
    livePriceTracking: "लाइव्ह भाव ट्रॅकिंग",
    marketPricesDesc: "रिअल-टाइम बाजार भाव ट्रॅक करा आणि सर्वोत्तम विक्री संधी मिळवा.",
    viewPrices: "भाव पहा",

    // Loan Services
    loanServices: "कर्ज सेवा",
    quickLoanApproval: "जलद कर्ज मंजुरी",
    loanServicesDesc: "शेती गरजांसाठी विविध बँकांकडून विविध कर्ज योजना मिळवा.",
    applyForLoan: "कर्जासाठी अर्ज करा",
    quickLoans: "जलद कर्जे",
    instantApproval: "तत्काळ मंजुरी उपलब्ध",
    apply: "अर्ज करा",
    viewAllLoans: "सर्व कर्जे पहा",
  },

  pa: {
    // Header
    appName: "CropAdvisor",
    tagline: "ਸਮਾਰਟ ਖੇਤੀ ਸਹਾਇਕ",
    country: "ਭਾਰਤ",
    voice: "ਆਵਾਜ਼",
    analytics: "ਵਿਸ਼ਲੇਸ਼ਣ",

    // Welcome Section
    welcome: "ਸਵਾਗਤ ਹੈ ਕਿਸਾਨ ਭਰਾ! 🌾",
    welcomeDesc: "ਤੁਹਾਡਾ ਨਿੱਜੀ ਫਸਲ ਸਲਾਹਕਾਰ ਡੈਸ਼ਬੋਰਡ ਅੱਜ ਦੀਆਂ ਸੂਝਾਂ ਨਾਲ ਤਿਆਰ ਹੈ।",

    // Kisan Call Center
    kisanCallCenter: "ਕਿਸਾਨ ਕਾਲ ਸੈਂਟਰ",
    freeSupport: "24x7 ਮੁਫਤ ਸਹਾਇਤਾ",
    callNow: "ਹੁਣੇ ਕਾਲ ਕਰੋ",
    immediateHelp: "ਤੁਰੰਤ ਸਹਾਇਤਾ ਲਈ",

    // Quick Stats
    soilHealth: "ਮਿੱਟੀ ਦੀ ਸਿਹਤ",
    soilGood: "ਚੰਗੀ",
    weather: "ਮੌਸਮ",
    sunny: "ਧੁੱਪ",
    pestRisk: "ਕੀੜੇ ਦਾ ਖਤਰਾ",
    low: "ਘੱਟ",
    market: "ਮਾਰਕੀਟ",
    rising: "ਵਧ ਰਿਹਾ ਹੈ",

    // Main Features
    cropAdvisory: "ਫਸਲ ਸਲਾਹ",
    aiRecommendations: "AI-ਸੰਚਾਲਿਤ ਸਿਫਾਰਸ਼ਾਂ",
    cropAdvisoryDesc: "ਆਪਣੀ ਮਿੱਟੀ, ਮੌਸਮ ਅਤੇ ਸਥਾਨ ਦੇ ਆਧਾਰ 'ਤੇ ਨਿੱਜੀ ਫਸਲ ਸਿਫਾਰਸ਼ਾਂ ਪ੍ਰਾਪਤ ਕਰੋ।",
    getRecommendations: "ਸਿਫਾਰਸ਼ਾਂ ਪ੍ਰਾਪਤ ਕਰੋ",

    weatherInfo: "ਮੌਸਮ ਜਾਣਕਾਰੀ",
    realtimeAlerts: "ਰੀਅਲ-ਟਾਈਮ ਮੌਸਮ ਚੇਤਾਵਨੀਆਂ",
    weatherDesc: "ਆਪਣੀਆਂ ਫਸਲਾਂ ਲਈ ਮੌਸਮ-ਆਧਾਰਿਤ ਚੇਤਾਵਨੀਆਂ ਅਤੇ ਭਵਿੱਖਬਾਣੀਆਂ ਨਾਲ ਅੱਗੇ ਰਹੋ।",
    viewWeather: "ਮੌਸਮ ਦੇਖੋ",

    pestDetection: "ਕੀੜੇ ਦੀ ਪਛਾਣ",
    aiImageAnalysis: "AI ਚਿੱਤਰ ਵਿਸ਼ਲੇਸ਼ਣ",
    pestDetectionDesc: "AI-ਸੰਚਾਲਿਤ ਵਿਸ਼ਲੇਸ਼ਣ ਨਾਲ ਕੀੜੇ ਅਤੇ ਬਿਮਾਰੀਆਂ ਦਾ ਪਤਾ ਲਗਾਉਣ ਲਈ ਫਸਲ ਦੀਆਂ ਤਸਵੀਰਾਂ ਅਪਲੋਡ ਕਰੋ।",
    scanCrop: "ਫਸਲ ਸਕੈਨ ਕਰੋ",

    marketPrices: "ਮਾਰਕੀਟ ਰੇਟ",
    livePriceTracking: "ਲਾਈਵ ਰੇਟ ਟਰੈਕਿੰਗ",
    marketPricesDesc: "ਰੀਅਲ-ਟਾਈਮ ਮਾਰਕੀਟ ਰੇਟਾਂ ਨੂੰ ਟਰੈਕ ਕਰੋ ਅਤੇ ਸਭ ਤੋਂ ਵਧੀਆ ਵਿਕਰੀ ਦੇ ਮੌਕੇ ਪ੍ਰਾਪਤ ਕਰੋ।",
    viewPrices: "ਰੇਟ ਦੇਖੋ",

    // Loan Services
    loanServices: "ਲੋਨ ਸੇਵਾਵਾਂ",
    quickLoanApproval: "ਤੇਜ਼ ਲੋਨ ਮਨਜ਼ੂਰੀ",
    loanServicesDesc: "ਖੇਤੀ ਦੀਆਂ ਲੋੜਾਂ ਲਈ ਵੱਖ-ਵੱਖ ਬੈਂਕਾਂ ਤੋਂ ਵੱਖ-ਵੱਖ ਲੋਨ ਸਕੀਮਾਂ ਤੱਕ ਪਹੁੰਚ ਕਰੋ।",
    applyForLoan: "ਲੋਨ ਲਈ ਅਰਜ਼ੀ ਦਿਓ",
    quickLoans: "ਤੇਜ਼ ਲੋਨ",
    instantApproval: "ਤੁਰੰਤ ਮਨਜ਼ੂਰੀ ਉਪਲਬਧ",
    apply: "ਅਰਜ਼ੀ ਦਿਓ",
    viewAllLoans: "ਸਾਰੇ ਲੋਨ ਦੇਖੋ",
  },
}

export type Language = keyof typeof translations
export type TranslationKey = keyof typeof translations.en

export const languages = [
  { code: "en" as Language, name: "English", nativeName: "English" },
  { code: "hi" as Language, name: "Hindi", nativeName: "हिन्दी" },
  { code: "bn" as Language, name: "Bengali", nativeName: "বাংলা" },
  { code: "te" as Language, name: "Telugu", nativeName: "తెలుగు" },
  { code: "ta" as Language, name: "Tamil", nativeName: "தமிழ்" },
  { code: "gu" as Language, name: "Gujarati", nativeName: "ગુજરાતી" },
  { code: "mr" as Language, name: "Marathi", nativeName: "मराठी" },
  { code: "pa" as Language, name: "Punjabi", nativeName: "ਪੰਜਾਬੀ" },
]
