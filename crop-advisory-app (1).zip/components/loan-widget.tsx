"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CreditCard, Building2, ArrowRight, ExternalLink } from "lucide-react"
import Link from "next/link"
import { useLanguage } from "@/contexts/language-context"
import { toast } from "sonner"

export function LoanWidget() {
  const { t } = useLanguage()

  const bankUrls: Record<string, string> = {
    SBI: "https://www.onlinesbi.sbi/",
    HDFC: "https://www.hdfcbank.com/",
    ICICI: "https://www.icicibank.com/",
  }

  const handleBankNavigation = (bankName: string) => {
    const url = bankUrls[bankName]
    if (url) {
      window.open(url, "_blank", "noopener,noreferrer")
      toast.success(`Redirecting to ${bankName} website`)
    } else {
      toast.error("Bank website not available")
    }
  }

  const quickLoans = [
    {
      name: "Kisan Credit Card",
      bank: "SBI",
      rate: "7%",
      amount: "₹3 Lakh",
      color: "bg-green-100 text-green-800",
    },
    {
      name: "Crop Loan",
      bank: "HDFC",
      rate: "8.5%",
      amount: "₹5 Lakh",
      color: "bg-blue-100 text-blue-800",
    },
    {
      name: "Farm Equipment",
      bank: "ICICI",
      rate: "9%",
      amount: "₹10 Lakh",
      color: "bg-purple-100 text-purple-800",
    },
  ]

  return (
    <Card className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm hover:shadow-xl transition-all duration-300 border-emerald-200 dark:border-emerald-800">
      <CardHeader>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg">
            <CreditCard className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-emerald-800 dark:text-emerald-200 text-lg">{t("quickLoans")}</CardTitle>
            <p className="text-sm text-gray-600 dark:text-gray-400">{t("instantApproval")}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {quickLoans.map((loan, index) => (
          <div
            key={index}
            className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <div className="flex items-center gap-3">
              <Building2 className="w-4 h-4 text-gray-500" />
              <div>
                <p className="font-medium text-sm text-gray-800 dark:text-gray-200">{loan.name}</p>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  {loan.bank} • {loan.rate} • {loan.amount}
                </p>
              </div>
            </div>
            <Badge
              className={`${loan.color} cursor-pointer hover:opacity-80 transition-opacity flex items-center gap-1`}
              onClick={() => handleBankNavigation(loan.bank)}
            >
              {t("apply")}
              <ExternalLink className="w-2 h-2" />
            </Badge>
          </div>
        ))}

        <div className="pt-2 border-t border-gray-200 dark:border-gray-600">
          <Link href="/loans">
            <Button className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 shadow-lg text-sm text-white">
              {t("viewAllLoans")}
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}
