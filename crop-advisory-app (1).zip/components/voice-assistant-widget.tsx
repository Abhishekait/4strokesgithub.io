"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Mic, Volume2, Globe } from "lucide-react"
import Link from "next/link"

export function VoiceAssistantWidget() {
  const [isListening, setIsListening] = useState(false)
  const [currentLanguage] = useState("English")

  return (
    <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Mic className="w-5 h-5 text-indigo-600" />
            <span>Voice Assistant</span>
          </div>
          <Link href="/voice">
            <Button size="sm" variant="outline" className="gap-2 bg-transparent">
              <Volume2 className="w-4 h-4" />
              Open
            </Button>
          </Link>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center">
          <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900 rounded-full flex items-center justify-center mx-auto mb-3">
            <Mic className="w-8 h-8 text-indigo-600 dark:text-indigo-400" />
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
            Get farming advice using voice commands in your preferred language
          </p>
        </div>

        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-gray-500" />
            <span>Language:</span>
          </div>
          <Badge variant="outline">{currentLanguage}</Badge>
        </div>

        <div className="flex items-center justify-between text-sm">
          <span>Status:</span>
          <Badge variant={isListening ? "default" : "secondary"}>{isListening ? "Listening" : "Ready"}</Badge>
        </div>
      </CardContent>
    </Card>
  )
}
