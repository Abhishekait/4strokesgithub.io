"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { TrendingUp, TrendingDown, BarChart3, IndianRupee, Wheat } from "lucide-react"
import Link from "next/link"

interface MarketPrice {
  crop: string
  currentPrice: number
  changePercent: number
  trend: "up" | "down" | "stable"
  market: string
}

export function MarketPriceWidget() {
  const [topPrices, setTopPrices] = useState<MarketPrice[]>([])

  useEffect(() => {
    const updatePrices = () => {
      const indianCrops = [
        { crop: "धान (Rice)", basePrice: 2850, market: "दिल्ली मंडी" },
        { crop: "गेहूं (Wheat)", basePrice: 2200, market: "पंजाब मंडी" },
        { crop: "मक्का (Maize)", basePrice: 1950, market: "UP मंडी" },
        { crop: "कपास (Cotton)", basePrice: 6500, market: "गुजरात मंडी" },
        { crop: "गन्ना (Sugarcane)", basePrice: 350, market: "महाराष्ट्र मंडी" },
        { crop: "सोयाबीन (Soybean)", basePrice: 4200, market: "MP मंडी" },
        { crop: "चना (Chickpea)", basePrice: 5800, market: "राजस्थान मंडी" },
        { crop: "सरसों (Mustard)", basePrice: 5200, market: "हरियाणा मंडी" },
        { crop: "प्याज (Onion)", basePrice: 1800, market: "नासिक मंडी" },
        { crop: "आलू (Potato)", basePrice: 1200, market: "UP मंडी" },
        { crop: "टमाटर (Tomato)", basePrice: 3500, market: "मुंबई मंडी" },
        { crop: "हल्दी (Turmeric)", basePrice: 8500, market: "तमिलनाडु मंडी" },
        { crop: "मिर्च (Chilli)", basePrice: 12000, market: "आंध्र प्रदेश मंडी" },
        { crop: "बाजरा (Pearl Millet)", basePrice: 2100, market: "राजस्थान मंडी" },
        { crop: "ज्वार (Sorghum)", basePrice: 2300, market: "महाराष्ट्र मंडी" },
      ]

      // Simulate real-time price fluctuations
      const selectedCrops = indianCrops.sort(() => 0.5 - Math.random()).slice(0, 4)
      const prices = selectedCrops.map((crop) => {
        const fluctuation = (Math.random() - 0.5) * 0.15 // ±15% fluctuation
        const currentPrice = Math.round(crop.basePrice * (1 + fluctuation))
        const changePercent = fluctuation * 100

        return {
          crop: crop.crop,
          currentPrice,
          changePercent: Number(changePercent.toFixed(1)),
          trend: changePercent > 2 ? "up" : changePercent < -2 ? "down" : "stable",
          market: crop.market,
        }
      })

      setTopPrices(prices)
    }

    updatePrices()
    // Update prices every 30 seconds to simulate real-time data
    const interval = setInterval(updatePrices, 30000)

    return () => clearInterval(interval)
  }, [])

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up":
        return <TrendingUp className="w-3 h-3 text-green-600" />
      case "down":
        return <TrendingDown className="w-3 h-3 text-red-600" />
      default:
        return <BarChart3 className="w-3 h-3 text-gray-600" />
    }
  }

  const getTrendColor = (changePercent: number) => {
    if (changePercent > 0) return "text-green-600 bg-green-50 border-green-200"
    if (changePercent < 0) return "text-red-600 bg-red-50 border-red-200"
    return "text-gray-600 bg-gray-50 border-gray-200"
  }

  return (
    <Card className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border-purple-200 dark:border-purple-800">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-gradient-to-br from-purple-500 to-violet-600 rounded-lg flex items-center justify-center">
              <IndianRupee className="w-4 h-4 text-white" />
            </div>
            <span className="text-purple-800 dark:text-purple-200">बाज़ार भाव</span>
          </div>
          <Link href="/market">
            <Button size="sm" variant="outline" className="gap-2 bg-white/50 hover:bg-white/80 border-purple-300">
              <BarChart3 className="w-4 h-4" />
              सभी देखें
            </Button>
          </Link>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {topPrices.length > 0 ? (
          topPrices.map((price, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-purple-50 to-violet-50 dark:from-purple-950 dark:to-violet-950 border border-purple-100 dark:border-purple-800"
            >
              <div className="flex-1">
                <p className="font-semibold text-sm text-gray-900 dark:text-white">{price.crop}</p>
                <p className="text-xs text-purple-600 dark:text-purple-400 flex items-center gap-1">
                  <Wheat className="w-3 h-3" />
                  {price.market}
                </p>
                <p className="text-sm font-bold text-purple-700 dark:text-purple-300">
                  ₹{price.currentPrice.toLocaleString()}/क्विंटल
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className={`gap-1 ${getTrendColor(price.changePercent)} font-medium`}>
                  {getTrendIcon(price.trend)}
                  {price.changePercent > 0 ? "+" : ""}
                  {price.changePercent}%
                </Badge>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-6">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-100 to-violet-100 dark:from-purple-900 dark:to-violet-900 rounded-full flex items-center justify-center mx-auto mb-3">
              <BarChart3 className="w-6 h-6 text-purple-600 dark:text-purple-400" />
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">मूल्य लोड हो रहे हैं...</p>
          </div>
        )}

        <div className="flex items-center justify-center pt-2 border-t border-purple-100 dark:border-purple-800">
          <div className="flex items-center gap-2 text-xs text-purple-600 dark:text-purple-400">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            लाइव अपडेट
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
