"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Cloud, Sun, CloudRain, Droplets, AlertTriangle } from "lucide-react"

interface WeatherWidgetProps {
  location?: string
  compact?: boolean
}

interface CurrentWeather {
  temperature: number
  condition: string
  humidity: number
  alerts: number
}

export function WeatherWidget({ location = "Current Location", compact = false }: WeatherWidgetProps) {
  const [weather, setWeather] = useState<CurrentWeather | null>(null)

  useEffect(() => {
    // Simulate weather API call
    setTimeout(() => {
      setWeather({
        temperature: 28,
        condition: "Partly Cloudy",
        humidity: 65,
        alerts: 2,
      })
    }, 1000)
  }, [])

  const getWeatherIcon = (condition: string) => {
    switch (condition.toLowerCase()) {
      case "sunny":
        return <Sun className="w-6 h-6 text-yellow-500" />
      case "partly cloudy":
        return <Cloud className="w-6 h-6 text-gray-500" />
      case "cloudy":
        return <Cloud className="w-6 h-6 text-gray-600" />
      case "rainy":
        return <CloudRain className="w-6 h-6 text-blue-500" />
      default:
        return <Sun className="w-6 h-6 text-yellow-500" />
    }
  }

  if (!weather) {
    return (
      <Card className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm animate-pulse">
        <CardContent className="p-4">
          <div className="h-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
        </CardContent>
      </Card>
    )
  }

  if (compact) {
    return (
      <Card className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {getWeatherIcon(weather.condition)}
              <div>
                <p className="font-bold text-lg">{weather.temperature}°C</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">{weather.condition}</p>
              </div>
            </div>
            {weather.alerts > 0 && (
              <Badge variant="destructive" className="gap-1">
                <AlertTriangle className="w-3 h-3" />
                {weather.alerts}
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-semibold text-lg">Current Weather</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">{location}</p>
          </div>
          {weather.alerts > 0 && (
            <Badge variant="destructive" className="gap-1">
              <AlertTriangle className="w-3 h-3" />
              {weather.alerts} alerts
            </Badge>
          )}
        </div>

        <div className="flex items-center gap-4">
          {getWeatherIcon(weather.condition)}
          <div>
            <p className="text-3xl font-bold">{weather.temperature}°C</p>
            <p className="text-gray-600 dark:text-gray-400">{weather.condition}</p>
          </div>
        </div>

        <div className="mt-4 flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Droplets className="w-4 h-4 text-blue-500" />
            <span className="text-sm">{weather.humidity}% humidity</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
