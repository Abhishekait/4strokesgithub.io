"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Zap, Loader2, Wheat } from "lucide-react"

interface FormData {
  location: string
  soilType: string
  cropType: string
  farmSize: string
  previousCrop: string
  budget: string
  additionalInfo: string
}

interface CropAdvisoryFormProps {
  onSubmit: (data: FormData) => void
  isLoading: boolean
}

export function CropAdvisoryForm({ onSubmit, isLoading }: CropAdvisoryFormProps) {
  const [formData, setFormData] = useState<FormData>({
    location: "",
    soilType: "",
    cropType: "",
    farmSize: "",
    previousCrop: "",
    budget: "",
    additionalInfo: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
  }

  return (
    <Card className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border-green-200 dark:border-green-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg flex items-center justify-center">
            <Wheat className="w-5 h-5 text-white" />
          </div>
          खेत की जानकारी
        </CardTitle>
        <CardDescription>व्यक्तिगत फसल सिफारिशें प्राप्त करने के लिए अपने खेत का विवरण प्रदान करें</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="location">स्थान</Label>
              <Input
                id="location"
                placeholder="अपना स्थान दर्ज करें"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="farmSize">खेत का आकार (हेक्टेयर)</Label>
              <Input
                id="farmSize"
                placeholder="उदा. 2.5"
                value={formData.farmSize}
                onChange={(e) => setFormData({ ...formData, farmSize: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="soilType">मिट्टी का प्रकार</Label>
              <Select
                value={formData.soilType}
                onValueChange={(value) => setFormData({ ...formData, soilType: value })}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="मिट्टी का प्रकार चुनें" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="clay">चिकनी मिट्टी</SelectItem>
                  <SelectItem value="sandy">रेतीली मिट्टी</SelectItem>
                  <SelectItem value="loamy">दोमट मिट्टी</SelectItem>
                  <SelectItem value="silt">गाद मिट्टी</SelectItem>
                  <SelectItem value="black">काली मिट्टी</SelectItem>
                  <SelectItem value="red">लाल मिट्टी</SelectItem>
                  <SelectItem value="alluvial">जलोढ़ मिट्टी</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="cropType">पसंदीदा फसल श्रेणी</Label>
              <Select
                value={formData.cropType}
                onValueChange={(value) => setFormData({ ...formData, cropType: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="फसल श्रेणी चुनें" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cereals">अनाज (चावल, गेहूं, मक्का)</SelectItem>
                  <SelectItem value="pulses">दालें (चना, मसूर, अरहर)</SelectItem>
                  <SelectItem value="oilseeds">तिलहन (सरसों, सूरजमुखी, मूंगफली)</SelectItem>
                  <SelectItem value="cash-crops">नकदी फसलें (कपास, गन्ना, जूट)</SelectItem>
                  <SelectItem value="vegetables">सब्जियां (टमाटर, प्याज, आलू)</SelectItem>
                  <SelectItem value="fruits">फल (आम, केला, अंगूर)</SelectItem>
                  <SelectItem value="spices">मसाले (हल्दी, धनिया, मिर्च)</SelectItem>
                  <SelectItem value="millets">मिलेट्स (बाजरा, ज्वार, रागी)</SelectItem>
                  <SelectItem value="fodder">चारा फसलें (बरसीम, ज्वार)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="previousCrop">पिछली फसल</Label>
              <Select
                value={formData.previousCrop}
                onValueChange={(value) => setFormData({ ...formData, previousCrop: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="पिछली फसल चुनें" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rice">धान</SelectItem>
                  <SelectItem value="wheat">गेहूं</SelectItem>
                  <SelectItem value="maize">मक्का</SelectItem>
                  <SelectItem value="cotton">कपास</SelectItem>
                  <SelectItem value="sugarcane">गन्ना</SelectItem>
                  <SelectItem value="soybean">सोयाबीन</SelectItem>
                  <SelectItem value="groundnut">मूंगफली</SelectItem>
                  <SelectItem value="mustard">सरसों</SelectItem>
                  <SelectItem value="chickpea">चना</SelectItem>
                  <SelectItem value="pigeon-pea">अरहर</SelectItem>
                  <SelectItem value="onion">प्याज</SelectItem>
                  <SelectItem value="potato">आलू</SelectItem>
                  <SelectItem value="tomato">टमाटर</SelectItem>
                  <SelectItem value="turmeric">हल्दी</SelectItem>
                  <SelectItem value="chilli">मिर्च</SelectItem>
                  <SelectItem value="none">कोई नहीं (पहली बार)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="budget">बजट रेंज (रुपये)</Label>
              <Select value={formData.budget} onValueChange={(value) => setFormData({ ...formData, budget: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="बजट रेंज चुनें" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">कम (₹50,000 से कम)</SelectItem>
                  <SelectItem value="medium">मध्यम (₹50,000 - ₹2,00,000)</SelectItem>
                  <SelectItem value="high">उच्च (₹2,00,000 से अधिक)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="additionalInfo">अतिरिक्त जानकारी</Label>
            <Textarea
              id="additionalInfo"
              placeholder="कोई विशिष्ट आवश्यकताएं, चुनौतियां या लक्ष्य?"
              value={formData.additionalInfo}
              onChange={(e) => setFormData({ ...formData, additionalInfo: e.target.value })}
              rows={3}
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 shadow-lg"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                विश्लेषण कर रहे हैं...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 mr-2" />
                AI सिफारिशें प्राप्त करें
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
