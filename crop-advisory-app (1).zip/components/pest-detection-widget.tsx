"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Bug, Camera, AlertTriangle, CheckCircle } from "lucide-react"
import Link from "next/link"

interface RecentDetection {
  id: string
  pest: string
  severity: "Low" | "Medium" | "High"
  date: string
  crop: string
}

export function PestDetectionWidget() {
  const [recentDetections] = useState<RecentDetection[]>([
    {
      id: "1",
      pest: "Aphids",
      severity: "Medium",
      date: "2 days ago",
      crop: "Tomatoes",
    },
    {
      id: "2",
      pest: "Leaf Spot",
      severity: "Low",
      date: "1 week ago",
      crop: "Lettuce",
    },
  ])

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "High":
        return "bg-red-100 text-red-800 border-red-300"
      case "Medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-300"
      case "Low":
        return "bg-green-100 text-green-800 border-green-300"
      default:
        return "bg-gray-100 text-gray-800 border-gray-300"
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "High":
        return <AlertTriangle className="w-3 h-3" />
      case "Medium":
        return <AlertTriangle className="w-3 h-3" />
      case "Low":
        return <CheckCircle className="w-3 h-3" />
      default:
        return <Bug className="w-3 h-3" />
    }
  }

  return (
    <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bug className="w-5 h-5 text-orange-600" />
            <span>Pest Detection</span>
          </div>
          <Link href="/pest-detection">
            <Button size="sm" variant="outline" className="gap-2 bg-transparent">
              <Camera className="w-4 h-4" />
              Scan
            </Button>
          </Link>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {recentDetections.length > 0 ? (
          <>
            <p className="text-sm text-gray-600 dark:text-gray-400">Recent detections:</p>
            {recentDetections.map((detection) => (
              <div
                key={detection.id}
                className="flex items-center justify-between p-2 rounded-lg bg-gray-50 dark:bg-gray-800"
              >
                <div className="flex-1">
                  <p className="font-medium text-sm">{detection.pest}</p>
                  <p className="text-xs text-gray-600 dark:text-gray-400">
                    {detection.crop} • {detection.date}
                  </p>
                </div>
                <Badge className={getSeverityColor(detection.severity)} size="sm">
                  {getSeverityIcon(detection.severity)}
                  {detection.severity}
                </Badge>
              </div>
            ))}
          </>
        ) : (
          <div className="text-center py-4">
            <Bug className="w-8 h-8 text-gray-400 mx-auto mb-2" />
            <p className="text-sm text-gray-600 dark:text-gray-400">No recent detections</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
