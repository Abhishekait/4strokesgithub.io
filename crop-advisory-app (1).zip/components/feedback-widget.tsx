"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Star, MessageSquare, Send } from "lucide-react"

export function FeedbackWidget() {
  const [rating, setRating] = useState(0)
  const [feedback, setFeedback] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = () => {
    // Simulate feedback submission
    setTimeout(() => {
      setIsSubmitted(true)
      setRating(0)
      setFeedback("")
    }, 1000)
  }

  if (isSubmitted) {
    return (
      <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
        <CardContent className="p-6 text-center">
          <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
            <MessageSquare className="w-6 h-6 text-green-600 dark:text-green-400" />
          </div>
          <h3 className="font-semibold mb-2">Thank you for your feedback!</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Your input helps us improve CropAdvisor for all farmers.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-blue-600" />
          Share Feedback
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Rating */}
        <div>
          <p className="text-sm font-medium mb-2">Rate your experience:</p>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <button key={star} onClick={() => setRating(star)} className="p-1">
                <Star
                  className={`w-6 h-6 ${
                    star <= rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300 dark:text-gray-600"
                  }`}
                />
              </button>
            ))}
          </div>
        </div>

        {/* Feedback Text */}
        <div>
          <p className="text-sm font-medium mb-2">Tell us more:</p>
          <Textarea
            placeholder="What did you like? What can we improve?"
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            rows={3}
          />
        </div>

        <Button onClick={handleSubmit} disabled={rating === 0} className="w-full bg-blue-600 hover:bg-blue-700">
          <Send className="w-4 h-4 mr-2" />
          Submit Feedback
        </Button>
      </CardContent>
    </Card>
  )
}
